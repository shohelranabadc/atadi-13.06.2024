<?php require_once 'inc/header.php'; ?>


        <section class="main_content_section">
            <div class="container px-0">
                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="page_heading text-center">
                            <h1 class="py-3">Contact</h1>
                            <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>

                <div class="row mx-0 my-3 justify-content-center">
                    <div class="col-md-8">
                      <div class="contact-form">
                        <form action="">
                          <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">নাম</label>
                            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="আপনার নাম লিখুন">
                          </div>
                          <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">মোবাইল নম্বর</label>
                            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="আপনার সাথে যোগাগের নম্বর লিখুন">
                          </div>
                          <div class="mb-3">
                            <label for="exampleFormControlInput1" class="form-label">ইমেইল</label>
                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="আপনার ইমেইল লিখুন">
                          </div>
        
                          <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">আপনার মতামত লিখুন</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="8"></textarea>
                          </div>
                          <div class="d-grid gap-2">
                            <button class="btn btn-outline-info fs-4" type="button">মতামত পাঠান</button>
                          </div>
                        </form>
                      </div>
                      </div>
                     
                      
                    </div>
            </div>
        </section>

        <?php require_once 'inc/footer.php'; ?>