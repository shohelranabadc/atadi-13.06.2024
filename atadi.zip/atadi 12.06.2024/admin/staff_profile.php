<?php
include __DIR__ . '/../vendor/autoload.php';

$staffProfileCon = new StaffProfileController();

if(isset($_GET['delid'])){
    $id = base64_decode($_GET['delid']);
    $deleteData = $staffProfileCon->deleteData($id);
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Staff Form</h4>
                        <a href="staff_profile_add" class="btn btn-primary">Add Staff</a>
                    </div>
                </div>
            </div>
            <!-- end page title -->


            <div class="row">
                <div class="col-12">
                    <table class="table">
                        <thead>
                            <th>#</th>
                            <th>ছবি</th>
                            <th>নাম</th>
                            <th>পদবী</th>
                            <th>ইনডেক্স নম্বর</th>
                            <th>শিক্ষাগত যোগতা</th>
                            <th>বেতন কোড</th>
                            <th>অভিজ্ঞতা</th>
                            <th>বিস্তারিত</th>
                            <th>Action</th>
                        </thead>
                        <tbody>
                        <?php
                            $results = $staffProfileCon->showData();

                            $count = 1;
                            if ($results) {
                                foreach ($results as $row){ ?>

                                <tr>
                                    <td><?php echo $count++ ?></td>
                                    <td><img src="./upload/staffProfile/<?= $row['image']; ?>" width="100" alt=""></td>
                                    <td><?= $row['name']; ?></td>
                                    <td><?= $row['designation']; ?></td>
                                    <td><?= $row['index_number']; ?></td>
                                    <td><?= $row['qualification']; ?></td>
                                    <td><?= $row['salary_code']; ?></td>
                                    <td><?= $row['experience']; ?></td>
                                    
                                    <td>

                                        <a href="staff_individual_profile.php??>">
                                            <button type="button" name="profile_detail_btn" class="btn btn-primary"> বিস্তারিত </button>
                                        </a>
                                    </td>
                                    <td>
                                        <!-- Edit button -->
                                        <a href="staff_profile_edit.php?Eid=<?=base64_encode($row['id']);?>">
                                            <button name="edit_btn" class="btn btn-primary"><i class="bi bi-pencil-square"></i></button>
                                        </a>
                                        <!-- Delete button -->
                                        <a onclick="return confirm('Are you sure to Delete')" href="?delid=<?=base64_encode($row['id']);?>">
                                            <button name="delete_btn" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                                        </a>
                                    </td>
                                </tr>
                                <?php }
                        } else {
                            echo "<div class='text-center'>
                                <span class='text-danger h2'>No Staff profile is Found </span>
                            </div>";
                        } ?>
                        </tbody>
                    </table>
                </div>
            </div>







        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>