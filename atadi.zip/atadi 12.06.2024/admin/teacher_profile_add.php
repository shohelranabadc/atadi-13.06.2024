<?php

include __DIR__ . '/../vendor/autoload.php';

$teacherProfileCon = new TeacherProfileController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $teacherProfileAdd = $teacherProfileCon->AddData($_POST, $_FILES);
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Teacher</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($teacherProfileAdd)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo $teacherProfileAdd; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Teacher Data Form</h4>
                                    <form class="repeater" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="name">নাম</label>
                                                <input class="form-control" name="name" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="email">ইনডেক্স নম্বর</label>
                                                <input class="form-control" name="index_number" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="subject">পদবী</label>
                                                <input class="form-control" name="designation" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="resume">জন্ম তারিখ</label>
                                                <input class="form-control" name="birth_of_date" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">১ম যোগদানের তারিখ</label>
                                                <input class="form-control" name="date_of_first_joining" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">১ম এমপিও চুক্তির তারিখ</label>
                                                <input class="form-control" name="date_of_first_mpo_agreement" type="text">
                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="name">বর্তমান পদে যোগদানের তারিখ</label>
                                                <input class="form-control" name="date_of_joining_present_post" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="email">বর্তমান পদে এমপিও চুক্তির তারিখ</label>
                                                <input class="form-control" name="date_of_mpo_contract_in_present_position" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="subject">বেতন কোড</label>
                                                <input class="form-control" name="salary_code" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="resume">নিয়োগের বিষয়</label>
                                                <input class="form-control" name="recruitment_subject" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">মোট অভিজ্ঞতা</label>
                                                <input class="form-control" name="total_experience" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="email">এএসসি/দাখিল</label>
                                                <input class="form-control" name="ssc_dakhil" type="text">

                                            </div>

                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="subject">এইচএসসি/আলিম</label>
                                                <input class="form-control" name="hsc_alim" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="resume">স্নাতক/ফাযিল</label>
                                                <input class="form-control" name="graduate_fazil" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">স্নাতকোত্তর/কামিল</label>
                                                <input class="form-control" name="post_graduate_kamil" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-2">
                                                <label class="form-label" for="message">বিএড/এমএড</label>
                                                <input class="form-control" name="bEd_mEd" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-4">
                                                <label class="form-label" for="message">ছবি</label>
                                                <input class="form-control" name="image" type="file">
                                            </div>


                                        </div>

                                        <button type="submit" class="btn btn-primary w-md" name="teacher_btn">Add Teacher</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>

           



        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>