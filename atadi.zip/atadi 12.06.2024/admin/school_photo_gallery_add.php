<?php

include __DIR__ . '/../vendor/autoload.php';

$photoGalleryCon = new PhotoGalleryController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $photoGalleryAdd = $photoGalleryCon->AddData($_FILES);
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">School Photo Gallary</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($photoGalleryAdd)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo $photoGalleryAdd; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">ফটো গ্যালারী</h4>
                            <form action="" method="POST" enctype="multipart/form-data">
                                <div class="col-md-6">
                                    <div class="input-group mb-3">
                                        <input type="file" class="form-control" name="image_name" id="inputGroupFile02">
                                        <label class="input-group-text" for="inputGroupFile02"><i class="fa-solid fa-plus"></i></label>
                                    </div>
                                </div>
                                <div class="mt-4">
                                    <button type="submit" class="btn btn-primary w-md" name="photo_gallery_btn">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<?php
include_once 'inc/footer.php';

?>