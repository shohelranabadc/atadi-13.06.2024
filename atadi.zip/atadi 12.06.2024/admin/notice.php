<?php
include __DIR__ . '/../vendor/autoload.php';

$noticeCon = new NoticeController();


?>



<!-- including header and sidebar -->
<?php

include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->

<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row mt-3 d-flex justify-content-center">
                <div class="col-9">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h1 class="mb-0">All Notice</h1>
                        <button class="btn btn-success waves-effect waves-light">
                            <i class="bi bi-plus me-1"></i>
                            <a href="notice_add.php" class="text-white">Add Notice</a>
                        </button>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <hr>

            <div class="row ">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($noticeCon->msg)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?= $noticeCon->msg; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>
                    
                    <table class="table table-hover">
                            <thead class="table-primary text-center">
                                <th>Id</th>
                                <th>Notice Title</th>
                                <th>Notice File</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                            <?php
                              
                            $results = $noticeCon->showData();

                            $count = 1;
                            if ($results) {
                                foreach ($results as $row){ ?>
                                        <tr class="table-info text-center">
                                            <td><?= $count++ ?></td>
                                            <td><?= $row['notice_title']; ?></td>
                                            <td> <a target="_blank" href="./upload/noticeFile/<?= $row['notice_file']; ?>"><?= $row['notice_file']; ?> </a> </td>
                                            <td>
                                                <a href="notice_edit.php?Eid=<?=base64_encode($row['id']);?>">
                                                    <button name="edit_btn" class="btn btn-success"><i class="bi bi-pencil-square"></i></button>
                                                </a>

                                                <a onclick="return confirm('Are you sure to Delete')" href="?delid=<?=base64_encode($row['id']);?>">
                                                    <button name="delete_btn" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    
                                    
                            <?php } 
                                    
                            } else {
                                echo "<div class='text-center'>
                                    <span class='text-danger h2'>No Notice Found </span>
                                </div>";
                            }

                            ?>

                        </tbody>
                     </table>
                </div>
            </div>







        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>