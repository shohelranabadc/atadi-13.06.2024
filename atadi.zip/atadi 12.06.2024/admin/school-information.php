<?php
include __DIR__ . '/../vendor/autoload.php';

$schoolInforCon = new SchoolInformationController();

if(isset($_GET['delid'])){
    $id = base64_decode($_GET['delid']);
    $deleteData = $schoolInforCon->deleteData($id);
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-10">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">School Information</h4>
                    </div>
                </div>
                <div class="col-2">
                <button class="btn btn-success waves-effect waves-light">
                    <i class="bi bi-plus me-1"></i>
                    <a href="school-information-add" class="text-white">Add Info</a>
                </button>
                </div>
            </div>
            <!-- end page title -->
            <hr>

            <div class="row justify-content-center">
                <div class="col-lg-10">
                        <div class="accordion" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    header Information Section
                                </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">

                                        <table class="table">

                                        <?php 

                                        $results = $schoolInforCon->showData();  

                                        if ($results) {
                                            foreach ($results as $row){ ?>
                                            <tr> 
                                                <td class="fw-bolder h5">School Name (Bangla)</td> <td> <?= $row['school_name_bangla']; ?></td>
                                                <td class="fw-bolder h5">School Name (English)</td> <td> <?= $row['school_name_english']; ?></td>
                                            </tr>
                                                        
                                            <tr> 
                                                <td class="fw-bolder h5">School Village Name</td> <td> <?= $row['school_village_name']; ?></td>
                                                <td class="fw-bolder h5">School Post Name</td> <td> <?= $row['school_post_name']; ?></td> 
                                            </tr>
                                                    
                                            <tr> 
                                                <td class="fw-bolder h5">School Police Station</td> <td> <?= $row['school_police_station']; ?></td>
                                                <td class="fw-bolder h5">School District Name</td> <td> <?= $row['school_district_name']; ?></td> 
                                            </tr>
                                                    
                                            <tr> 
                                                <td class="fw-bolder h5">School MPO Code</td> <td> <?= $row['school_mpo_code']; ?></td>
                                                <td class="fw-bolder h5">School EIIN Number</td> <td> <?= $row['school_eiin_number']; ?></td>
                                            </tr>
                                            <?php }
                                                 } else {
                                                    echo "<div class='text-center'>
                                                        <span class='text-danger h2'>No Information is Found </span>
                                                    </div>";
                                                }  ?>

                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Footer Information Section
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <table class="table">
                                        <?php 

                                            $results = $schoolInforCon->showData(); 

                                            if ($results) {
                                                foreach ($results as $row){ ?>
                                            <tr> 
                                                <td class="fw-bolder h5">School Establishment Date</td> <td> <?= $row['school_establishment_date']; ?></td>
                                                    <td class="fw-bolder h5">School Email Address</td> <td> <?= $row['school_email_address']; ?></td>
                                            </tr>
                                                    
                                            <tr> 
                                                <td class="fw-bolder h5">School Mobile Number</td> <td> <?= $row['school_mobile_number']; ?></td>
                                                <td class="fw-bolder h5">School Location URL (map)</td> <td> <?= $row['school_location_url']; ?></td>
                                            </tr>
                                                        
                                            <tr> <td class="fw-bolder h5">Copy Right Starting Date</td> <td> <?= $row['copy_right_date']; ?></td> </tr>
                                            <?php }
                                                 } else {
                                                    echo "<div class='text-center'>
                                                        <span class='text-danger h2'>No Information is Found </span>
                                                    </div>";
                                                }  ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    <!--Accordon finised  -->

                    <!-- Action Button start -->
                    <div class="d-flex justify-content-end mt-3">
                        <a href="school-information-edit.php?Eid=<?=base64_encode($row['id']);?>" class="me-2">
                            <button type="button" name="edit_btn" class="btn btn-primary"><i class="bi bi-pencil-square me-2"></i>Edit</button>
                        </a>

                        <a onclick="return confirm('Are you sure to Delete')" href="?delid=<?=base64_encode($row['id']);?>">
                            <button name="delete_btn" class="btn btn-danger"><i class="bi bi-trash me-2"></i>Delete</button>
                        </a>
                    </div>
                    <!-- Action Button end -->

                    
      
                </div> 
                <!-- colmumn end -->
            </div>
            <!-- row end -->

            

            




        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>