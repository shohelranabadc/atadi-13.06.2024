<?php
include __DIR__ . '/../vendor/autoload.php';



$directorProfileCon = new DirectorProfileController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}




if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $directorProfileUpdate = $directorProfileCon->updateData($_POST, $_FILES, $Eid);
    
}

include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Director</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <span>
                        <?php
                        if (isset($directorProfileUpdate)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?php echo $directorProfileUpdate; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Director Data Form</h4>
                                    <?php
                                    $row = $directorProfileCon->getDataById($Eid);
                                   
                                    if ($row) { ?>
                                    <form class="repeater" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="mb-3 col-lg-3">
                                                <label class="form-label" for="name">নাম</label>
                                                <input class="form-control" name="name" value="<?= $row['name']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-3">
                                                <label class="form-label" for="subject">পদবী</label>
                                                <input class="form-control" name="designation" value="<?= $row['designation']; ?>" type="text">
                                            </div>

                                            <div class="mb-3 col-lg-3">
                                                <label class="form-label" for="email">মোবাইল নম্বর</label>
                                                <input class="form-control" name="contact_number" value="<?= $row['contact_number']; ?>" type="text">
                                            </div>
                                        </div>

                                        
                                </div>
                                <img src="upload/directorProfile/<?= $row['image'] ?>" alt="" class="img-thumbnail" width="250" height="250">
                                <br><br>
                                <div class="col-md-6">
                                    <div class="input-group mb-3">
                                        <input type="file" onchange="ImgShow(event)" class="form-control" name="image">
                                        <label class="input-group-text" for="inputGroupFile02"><i class="fa-solid fa-plus"></i></label>
                                    </div>
                                    <img id="output" src="./assets/demoImage.jpg" alt="" width="150" height="150">
                                </div>
                                    <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                </form>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end col -->
        </div>


    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->


<?php
include_once 'inc/footer.php';

?>

<script>
    function ImgShow(event) {
        var img = document.getElementById("output");
        img.src = URL.createObjectURL(event.target.files[0]);
    };
</script>