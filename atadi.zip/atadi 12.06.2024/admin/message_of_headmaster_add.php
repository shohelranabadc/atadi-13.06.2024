<?php

include __DIR__ . '/../vendor/autoload.php';

$headmasterMessageCon = new HeadmasterMessageController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $headmasterMessageAdd = $headmasterMessageCon->AddData($_POST, $_FILES);
}

    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">প্রধান শিক্ষকের বার্তা লিখুন</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                            <span>
                                <?php 
                                    if(isset($headmasterMessageAdd)){
                                                                ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <?php echo $headmasterMessageAdd; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                }
                    
                                ?>
                            </span>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title"> প্রধান শিক্ষকের ছবি দিন </h4>
                                        <form action="" method="POST" enctype="multipart/form-data">
                                            <div class="mb-3 row">
                                                <div class="col-md-10">
                                                    <div class="input-group mb-3">
                                                        <input type="file" class="form-control" name="image_name" id="inputGroupFile02"> 
                                                        <label class="input-group-text" for="inputGroupFile02"><i class="fa-solid fa-plus"></i></label>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3 row">
                                                <div class="col-md-10">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <h4 class="card-title">প্রধান শিক্ষকের বিস্তারিত বার্তা</h4>
                                                            <textarea name="long_message" id="classic-editor-two" cols="30" rows="10"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mt-4">
                                                <button type="submit" class="btn btn-primary w-md" name="message_btn">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>

                        
                        

                       

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>