<?php
include __DIR__ . '/../vendor/autoload.php';

$importantLinkCon = new ImportantLinkController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $importantLinkUpdate = $importantLinkCon->updateData($_POST, $Eid);
    
}



    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">জরুরী লিংক পেজ</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                            <span>
                                <?php 
                                    if(isset($importantLinkUpdate)){
                                                                ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <?php echo $importantLinkUpdate; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                }
                    
                                ?>
                            </span>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">জরুরী লিংক</h4>
                                        <?php 
                                         $results = $importantLinkCon->getDataById($Eid);
                                         if ($results) {
                                         foreach ($results as $row){ ?>
                                        <form action="" method="POST" enctype="multipart/form-data">
                                            <div class="mb-3 row">
                                                <div class="col-md-10">
                                                    <input class="form-control" name="url_link" type="text" value="<?php echo $row['url_link'];?>" id="example-text-input">
                                                </div>
                                            </div>
                                            <div class="mb-3 row">
                                                <div class="col-md-10">
                                                    <input class="form-control" name="url_title" type="text" value="<?php echo $row['url_title'];?>" id="example-text-input">
                                                </div>
                                            </div>
                                            
                                            <div class="mt-4">
                                                <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                            </div>
                                        </form>
                                        <?php } } ?>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>

                        <hr>

                      
                          

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>