<?php include_once 'libs/RowCountController.php'; 
$rowCount = new RowCountController();



?>

<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="index" class="logo logo-dark">
            <span class="logo-sm">
                <img src="./assets/images/logo-dashboard.png" alt="" height="40">
            </span>
            <span class="logo-lg">
                <img src="./assets/images/logo-dashboard.png" alt="" height="40">
            </span>
        </a>

        <a href="index" class="logo logo-light">
            <span class="logo-sm">
                <img src="./assets/images/logo-dashboard.png" alt="" height="40">
            </span>
            <span class="logo-lg">
                <img src="./assets/images/logo-dashboard.png" alt="" height="40">
            </span>
        </a>
    </div>

    <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect vertical-menu-btn">
        <i class="fa fa-fw fa-bars"></i>
    </button>

    <div data-simplebar class="sidebar-menu-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="index"> 
                        <i class="bi bi-speedometer"></i>
                        <span class="badge rounded-pill bg-primary float-end">01</span>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="javascript: void(0);"><i class="bi bi-info-square-fill"></i>school Theme</a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li><a href="school-information">School Information</a></li>
                        <li><a href="school-theme-media">school Media</a></li>
                    </ul>
                </li>


                <li>
                    <a href="notice">
                        <i class="bi bi-bell-fill"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->noticeCount(); ?></span>
                        <span>Notice page</span>
                    </a>
                </li>
                <li>
                    <a href="slider_page">
                        <i class="bi bi-sliders"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->sliderImageCount(); ?></span>
                        <span>Slider Image</span>
                    </a>
                </li>
                <li>
                    <a href="about_school">
                        <i class="bi bi-mortarboard-fill"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->aboutSchoolCount(); ?></span>
                        <span>About School Page</span>
                    </a>
                </li>
                
                    <li>
                        <a href="message_of_chairman">
                            <i class="bi bi-chat-fill"></i>
                            <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->chairmanMessageCount(); ?></span>
                            <span>Chairman Message</span>
                        </a>
                    </li>
                


                
                    <li>
                        <a href="message_of_headmaster">
                            <i class="bi bi-chat-fill"></i>
                            <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->headmasterMessageCount(); ?></span>
                            <span>Headmaster Message</span>
                        </a>
                    </li>
               

                <li>
                    <a href="school_photo_gallery">
                        <i class="bi bi-images"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->schoolPhotoGalleryCount(); ?></span>
                        <span>School Photo Gallery</span>
                    </a>
                </li>

                <li>
                    <a href="board_of_director_profile">
                        <i class="bi bi-person-circle"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->directorProfileCount(); ?></span>
                        <span>Director profile</span>
                    </a>
                </li>

                <li>
                    <a href="teacher_profile">
                        <i class="bi bi-person-square"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->teacherProfileCount(); ?></span>
                        <span>Teacher profile</span>
                    </a>
                </li>

                <li>
                    <a href="staff_profile">
                        <i class="bi bi-people-fill"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->staffProfileCount(); ?></span>
                        <span>Staff profile</span>
                    </a>
                </li>

                <li>
                    <a href="class_routine">
                        <i class="bi bi-bell-fill"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->ClassRoutineCount(); ?></span>
                        <span>Class Routine</span>
                    </a>
                </li>

                <li>
                    <a href="exam_routine">
                        <i class="bi bi-bell-fill"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->ExamRoutineCount(); ?></span>
                        <span>Exam Routine</span>
                    </a>
                </li>

                <li>
                    <a href="important_link">
                        <i class="bi bi-link-45deg"></i>
                        <span class="badge rounded-pill bg-primary float-end"><?= $rowCount->importantLinkCount(); ?></span>
                        <span>Important Link</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->