<?php 
include __DIR__ . '/../vendor/autoload.php';

$UserCon = new UserController();

if(isset($_GET['deactive'])){
    $deactiveId = $_GET['deactive'];
    $deactiveUser = $UserCon->deactiveUser($deactiveId);
}

if(isset($_GET['active'])){
    $activeId = $_GET['active'];
    $activeUser = $UserCon->activeUser($activeId);
}

if(isset($_GET['delid'])){
    $Did = base64_decode($_GET['delid']);
    $deleteUser = $UserCon->deleteUserData($Did);
}



?>



<!-- include Header and Sidebar -->
<?php include_once 'inc/header.php'; ?>
<?php include_once 'inc/sidebar.php'; ?>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">User List </h4>
                                    <div>
                                        <button type="button" class="btn btn-success waves-effect waves-light mb-3"><i class="mdi mdi-plus me-1"></i> Add User</button> 
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->
                        
                        <div class="row">
                            <div class="col-lg-12">
                                <div>

                                    <div class="table-responsive mb-4">
                                        <table class="table table-centered datatable dt-responsive nowrap table-card-list" style="border-collapse: collapse; border-spacing: 0 12px; width: 100%;">
                                            <thead>
                                                <tr class="bg-transparent">
                                                    <th style="width: 20px;">
                                                        <div class="form-check text-center">
                                                            <input type="checkbox" class="form-check-input" id="customercheck">
                                                            <label class="form-check-label" for="customercheck"></label>
                                                        </div>
                                                    </th>
                                                    <th style="width: 120px;">User ID</th>
                                                    <th>User Name</th>
                                                    <th>Email</th>
                                                    <th>User Role</th>
                                                    <th>Status</th>
                                                    <th style="width: 120px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $results = $UserCon->showData();

                                                $count = 1;
                                                if ($results) {
                                                foreach ($results as $row){  ?>
                                                    
                                                        <?php 
                                                            $user_id = $row['user_id'];
                                                            $loginId = Session::get("loginId");
                                                            $userLoginRole = Session::get("user_role");
                                                            $userLoginName = Session::get("user_name");
                                                            $userLoginEmail = Session::get("user_email");
                                                            $userUserStatus = Session::get("user_status");

                                                            switch ( $userLoginRole ) {
                                                                case '1': ?>
                                                                            <tr>
                                                                                <td>
                                                                                    <div class="form-check text-center">
                                                                                        <input type="checkbox" class="form-check-input" id="customercheck1">
                                                                                        <label class="form-check-label" for="customercheck1"></label>
                                                                                    </div>
                                                                                </td>
                                                                            
                                                                                <td><a href="javascript: void(0);" class="text-dark fw-bold"><?= $count++; ?></a> </td>
                                                                                <td>
                                                                                    <img src="assets/images/users/avatar-2.jpg" alt="" class="avatar-xs rounded-circle me-2">
                                                                                    <span><?= $row['user_name']; ?></span>
                                                                                </td>
                                                                                <td><?= $row['user_email']; ?></td>
                                                                            
                                                                                <td> 
                                                                                    <?php 
                                                                                        if($row['user_role'] == 0) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-info font-size-12 px-3 py-2">Panding User</span>
                                                                                        <?php elseif($row['user_role'] == 3) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-dark font-size-12 px-3 py-2">User</span>
                                                                                        <?php elseif($row['user_role'] == 2) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-danger font-size-12 px-3 py-2">Admin</span>
                                                                                        <?php elseif($row['user_role'] == 1) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-success font-size-12 px-3 py-2"> Super Admin</span>
                                                                                    <?php endif ?>
                                                                                </td>

                                                                                <td>
                                                                                    <?php 
                                                                                        if($row['user_status'] == 0) {?>
                                                                                        <a href="?deactive=<?=$row['user_id'] ?>" class="btn btn-danger waves-effect waves-purple font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Deactive</a>
                                                                                <?php }else{ ?> 
                                                                                    <a href="?active=<?=$row['user_id'] ?>"class="btn btn-success btn-large waves-effect waves-red font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Active</a>
                                                                                    <?php } ?>
                                                                                </td>
                                                                                <td class="d-flex">
                                                                                <?php 
                                                                                if($loginId == $row['user_id'] || $row['user_role'] >= 0 && $row['user_status'] == 1) : ?>
                                                                                <a href="user-edit.php?Eid=<?= base64_encode($row['user_id']); ?>" class="px-2 text-primary"><i class="bi bi-pen font-size-18"></i></a>
                                                                                <a onclick="return confirm('Are you sure to Delete User ?')" href="?delid=<?=base64_encode($row['user_id']);?>" class="px-2 text-danger"><i class="bi bi-trash font-size-18"></i></a>                         
                                                                                <?php endif ?>
                                                                            </td>
                                                                            </tr>
                                                                        
                                                                        <?php break;
                                                                case '2' : ?>

                                                                            <tr>
                                                                                <td>
                                                                                    <div class="form-check text-center">
                                                                                        <input type="checkbox" class="form-check-input" id="customercheck1">
                                                                                        <label class="form-check-label" for="customercheck1"></label>
                                                                                    </div>
                                                                                </td>
                                                                            
                                                                                <td><a href="javascript: void(0);" class="text-dark fw-bold"><?= $count++; ?></a> </td>
                                                                                <td>
                                                                                    <img src="assets/images/users/avatar-2.jpg" alt="" class="avatar-xs rounded-circle me-2">
                                                                                    <span><?= $row['user_name']; ?></span>
                                                                                </td>
                                                                                <td><?= $row['user_email']; ?></td>
                                                                            
                                                                                <td>
                                                                                    <?php 
                                                                                        if($row['user_role'] == 0) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-info font-size-12 px-3 py-2">Panding User</span>
                                                                                        <?php elseif($row['user_role'] == 3) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-dark font-size-12 px-3 py-2">User</span>
                                                                                        <?php elseif($row['user_role'] == 2) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-danger font-size-12 px-3 py-2">Admin</span>
                                                                                        <?php elseif($row['user_role'] == 1) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-success font-size-12 px-3 py-2"> Super Admin</span>
                                                                                    <?php endif ?> 
                                                                                    
                                                                                </td>

                                                                                <td>
                                                                                    <?php 
                                                                                    if($row['user_id'] == 0){
                                                                                        if($row['user_status'] == 0) {?>
                                                                                        <a href="?deactive=<?=$row['user_id'] ?>" class="btn btn-danger waves-effect waves-purple font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Deactive</a>
                                                                                <?php }else{ ?> 
                                                                                    <a href="?active=<?=$row['user_id'] ?>"class="btn btn-success btn-large waves-effect waves-red font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Active</a>
                                                                                    <?php } }?>
                                                                                </td>
                                                                                <td class="d-flex">
                                                                                <?php 
                                                                                if ( $loginId == $row['user_id']) { ?>
                                                                                    <a href="user-edit.php?Eid=<?= base64_encode($row['user_id']); ?>" class="px-2 text-primary"><i class="bi bi-pen font-size-18"></i></a>
                                                                                    
                                                                                <?php }elseif($row['user_status'] == 1 && $row['user_role'] != 1 && $row['user_role'] != 2 && $row['user_role'] == 3 || $row['user_role'] == 0) {  ?>
                                                                                    <a href="user-edit.php?Eid=<?= base64_encode($row['user_id']); ?>" class="px-2 text-primary"><i class="bi bi-pen font-size-18"></i></a>
                                                                                    <a onclick="return confirm('Are you sure to Delete User ?')" href="?delid=<?=base64_encode($row['user_id']);?>" class="px-2 text-danger"><i class="bi bi-trash font-size-18"></i></a>
                                                                                    <?php } ?>
                                                                                                            
                                                                                </td>
                                                                            </tr>
                                                                        <?php break;
                                                                case '3' : ?>
                                                                            <tr>
                                                                                <td>
                                                                                    <div class="form-check text-center">
                                                                                        <input type="checkbox" class="form-check-input" id="customercheck1">
                                                                                        <label class="form-check-label" for="customercheck1"></label>
                                                                                    </div>
                                                                                </td>
                                                                            
                                                                                <td><a href="javascript: void(0);" class="text-dark fw-bold"><?= $count++; ?></a> </td>
                                                                                <td>
                                                                                    <img src="assets/images/users/avatar-2.jpg" alt="" class="avatar-xs rounded-circle me-2">
                                                                                    <span><?= $row['user_name']; ?></span>
                                                                                </td>
                                                                                <td><?= $row['user_email']; ?></td>
                                                                            
                                                                                <td>
                                                                                    <?php 
                                                                                        if($row['user_role'] == 0) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-info font-size-12 px-3 py-2">Panding User</span>
                                                                                        <?php elseif($row['user_role'] == 3) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-dark font-size-12 px-3 py-2">User</span>
                                                                                        <?php elseif($row['user_role'] == 2) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-danger font-size-12 px-3 py-2">Admin</span>
                                                                                        <?php elseif($row['user_role'] == 1) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-success font-size-12 px-3 py-2"> Super Admin</span>
                                                                                    <?php endif ?> 
                                                                                    
                                                                                </td>

                                                                                <td>
                                                                                    <?php 
                                                                                        if($row['user_id'] == 0){
                                                                                            if($row['user_status'] == 0) {?>
                                                                                            <a href="?deactive=<?=$row['user_id'] ?>" class="btn btn-danger waves-effect waves-purple font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Deactive</a>
                                                                                    <?php }else{ ?> 
                                                                                        <a href="?active=<?=$row['user_id'] ?>"class="btn btn-success btn-large waves-effect waves-red font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Active</a>
                                                                                    <?php } } ?>
                                                                                </td>
                                                                                <td class="d-flex">
                                                                                    <?php 
                                                                                if ($loginId == $row['user_id'] || $userLoginRole == 1) { ?>
                                                                                    <a href="user-edit.php?Eid=<?= base64_encode($row['user_id']); ?>" class="px-2 text-primary"><i class="bi bi-pen font-size-18"></i></a>
                                                                                    <a onclick="return confirm('Are you sure to Delete User ?')" href="?delid=<?=base64_encode($row['user_id']);?>" class="px-2 text-danger"><i class="bi bi-trash font-size-18"></i></a>
                                                                                <?php }  ?>
                                                                                
                                                                                                            
                                                                                </td>
                                                                            </tr>

                                                                        <?php  break;

                                                                    case '0' : ?>
                                                                        <tr>
                                                                            <td>
                                                                                <div class="form-check text-center">
                                                                                    <input type="checkbox" class="form-check-input" id="customercheck1">
                                                                                    <label class="form-check-label" for="customercheck1"></label>
                                                                                </div>
                                                                            </td>
                                                                        
                                                                            <td><a href="javascript: void(0);" class="text-dark fw-bold"><?= $count++; ?></a> </td>
                                                                            <td>
                                                                                <img src="assets/images/users/avatar-2.jpg" alt="" class="avatar-xs rounded-circle me-2">
                                                                                <span><?= $row['user_name']; ?></span>
                                                                            </td>
                                                                            <td><?= $row['user_email']; ?></td>
                                                                        
                                                                            <td> 
                                                                                <?php 
                                                                                    if($row['user_role'] == 0) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-info font-size-12 px-3 py-2">Panding User</span>
                                                                                        <?php elseif($row['user_role'] == 3) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-dark font-size-12 px-3 py-2">User</span>
                                                                                        <?php elseif($row['user_role'] == 2) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-danger font-size-12 px-3 py-2">Admin</span>
                                                                                        <?php elseif($row['user_role'] == 1) : ?>
                                                                                            <span class="badge rounded-pill bg-soft-success font-size-12 px-3 py-2"> Super Admin</span>
                                                                                <?php endif ?>    
                                                                            </td>

                                                                            <td>
                                                                                <?php 
                                                                                    if($row['user_id'] == 0){
                                                                                        if($row['user_status'] == 0) {?>
                                                                                        <a href="?deactive=<?=$row['user_id'] ?>" class="btn btn-danger waves-effect waves-purple font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Deactive</a>
                                                                                <?php }else{ ?> 
                                                                                    <a href="?active=<?=$row['user_id'] ?>"class="btn btn-success btn-large waves-effect waves-red font-size-12 <?= $row['user_status'] == 1 ? "bg-soft-success" : "bg-soft-danger";?> ">Active</a>
                                                                                <?php } } ?>
                                                                            </td>
                                                                            <td class="d-flex">
                                                                        <?php 
                                                                            if ($loginId == $row['user_id'] || $userLoginRole == 1) { ?>
                                                                                <a href="user-edit.php?Eid=<?= base64_encode($row['user_id']); ?>" class="px-2 text-primary"><i class="bi bi-pen font-size-18"></i></a>
                                                                                <a onclick="return confirm('Are you sure to Delete User ?')" href="?delid=<?=base64_encode($row['user_id']);?>" class="px-2 text-danger"><i class="bi bi-trash font-size-18"></i></a>
                                                                        <?php }  ?>
                                                                            
                                                                                                        
                                                                            </td>
                                                                        </tr>

                                                                    <?php  break;



                                                                default: ?>
                                                                    echo "defoult User";
                                                            <?php } ?>
                                                                     
                                                    <?php } } ?>
   
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->





















    </div> <!-- container-fluid -->
</div> <!-- End Page-content -->
    
<!-- include Footer -->
<?php include_once 'inc/footer.php'; ?>