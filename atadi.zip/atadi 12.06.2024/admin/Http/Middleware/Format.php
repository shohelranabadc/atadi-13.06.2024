<?php

class Format{

    public function validation($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        $data = htmlspecialchars_decode($data);
        $data = strip_tags($data);
        return $data;
    }
}

?>