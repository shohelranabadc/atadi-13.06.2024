<?php

require_once __DIR__ . "/../../Models/ImportantLinkModel.php";

include_once __DIR__ . "/../Middleware/Format.php";



class ImportantLinkController
{

    public $model;

    public $table = 'tbl_important_link';     // change table name

    public $fr;
    
    public $msg;

    public function __construct()
    {
        $this->model = new ImportantLinkModel();   // change model controller name

        $this->fr = new Format();
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll($this->table);

        return $result ? $result : false;
    }

    // Add Notice 
    public function AddData($data){

        $url_link = $this->fr->validation($data['url_link']);
        $url_title = $this->fr->validation($data['url_title']);

              // PROCESS DATA AND SENT INTO DATABASE MODEL 
            $result = $this->model->insert($url_link, $url_title, $this->table); // include variable name

            if ($result) {
                header('Location: important_link.php'); // change Redirect file name
                $this->msg = "Data Insert Succesfully";
            } else {
                $this->msg = "Data insert Failed";  
            }
            return $this->msg;
        }
    
   
    

    // Data Delete
    public function deleteData($id){

        // delete Data from model
        $result = $this->model->delete($id, $this->table);
        
        if ($result == true) {
            $this->msg = "Data deleted successfully";

        } else {
            $this->msg = "Data delete Failed"; 
        }
        return $this->msg;
    }
 

    public function getDataById($id){

        $result = $this->model->selectById($id, $this->table);
       
        return $result ? $result : false;

    }

   

// Data Edit and Update method
    public function updateData($data, $id){

        $url_link = $this->fr->validation($data['url_link']);
        $url_title = $this->fr->validation($data['url_title']);

        $result = $this->model->update($url_link, $url_title, $id, $this->table);

        if ($result) {
            $this->msg = "File and Data Update successfully";
            } else {
                $this->msg = "File and Data Update Failed";
            }
            return $this->msg;
        }
                

}
