<?php

require_once __DIR__ . "/../../Models/SchoolMediaModel.php";

include_once __DIR__ . "/../Middleware/Format.php";



class SchoolMediaController
{

    public $model;
   
    public $msg;

    public function __construct()
    {
        $this->model = new SchoolMediaModel();   // change model controller name
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll();

        if($result){
            return $result;
        }else{
            return false;
        }
        
    }

    // Add Notice 
    public function AddData($data, $file){

        $result = $this->model->insert($data, $file);

        

        if($result){
            header('Location: school-theme-media.php'); // change Redirect file name

            return $this->msg = '<div class="alert alert-success py-2 fs-4 alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill"></i> <strong>Successfully!</strong> Data Inserted!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>';
        
        }else{
            return $this->msg = '<div class="alert alert-danger py-2 fs-4 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> <strong>Data!</strong> not inserted !
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }
    } // add notice method

   
    

    
 

    public function getDataById($id){

        $result = $this->model->selectById($id);
       
        if ($result) {
            return $result;
        } else {
            return false;
        }

    }

// Data Edit and Update method
    public function updateData($data, $file, $id){

       
       return $result = $this->model->update($data, $file, $id);

    }

    // Data Delete
    public function deleteData($id){

        // select unlink file from model
        $this->unlinkFile($id);

        // delete Data from model
        $result = $this->model->delete($id);

        
        if ($result == true) {
            $this->msg = "Data deleted successfully";
            // return $this->msg;
        } else {
            $this->msg = "Data delete Failed";
            return $this->msg;
        }
    }



    // Unlink file method
    public function unlinkFile($id){

        // select unlink file from model
        $result = $this->model->selectById($id);

        // unlink notice file
        if ($result) {
            while ($row = $result->fetch()) {
                $file = $row["logo"];   // change column or file name
                unlink("upload/schoolThemeMedia/" . $file); // change folder name
            }
        }
    }




}
