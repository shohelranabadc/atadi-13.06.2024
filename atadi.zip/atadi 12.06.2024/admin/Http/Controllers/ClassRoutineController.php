<?php

require_once __DIR__ . "/../../Models/ClassRoutineModel.php";

include_once __DIR__ . "/../Middleware/Format.php";



class ClassRoutineController
{

    public $model;

    public $table = 'tbl_class_routines';     // change table name

    public $fr;
    
    public $msg;

    public function __construct()
    {
        $this->model = new ClassRoutineModel();

        $this->fr = new Format();
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll($this->table);

        return $result ? $result : false;
    }

    // Add Notice 
    public function AddData($data, $file){

        $class_routines_title = $this->fr->validation($data['class_routines_title']);

        $file_name = $this->fr->validation($file['class_routines_file']['name']);
        $file_type = $this->fr->validation($file['class_routines_file']['type']);
        $file_size = $this->fr->validation($file['class_routines_file']['size']);
        $file_location = $file['class_routines_file']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $permited = array('pdf', 'jpg', 'jpeg', 'png');

        $file_store = "upload/classRoutine/" . $unique_file;

        if (empty($class_routines_title) and empty($file_name)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        } elseif ($file_size > 10048567) {
            $this->msg = "File size must be less then 1 MB";
            return $this->msg;
        } elseif (in_array($file_exten, $permited) == false) {
            $this->msg = "you can upload only" . implode(', ', $permited);
            return $this->msg;
        } else {
            move_uploaded_file($file_location, $file_store);

            // PROCESS DATA AND SENT INTO DATABASE MODEL 
            $result = $this->model->insert($class_routines_title, $unique_file, $this->table);

            if ($result) {
                header('Location: class_routine.php');
                $this->msg = "Routine Insert Succesfully";
            } else {
                $this->msg = "Routine insert Failed";  
            }
            return $this->msg;
        }
    } // add notice method

   
    

    // Notice Delete
    public function deleteData($id)
    {
        // select unlink file from model
        $this->unlinkFile($id);

        // delete notice from model
        $result = $this->model->delete($id, $this->table);

        
        if ($result) {
            $this->msg = "Routine delete successfull";
            // return $this->msg;
        } else {
            $this->msg = "Routine delete Failed";
            return $this->msg;
        }
    }
 

    public function getDataById($id){
        $result = $this->model->selectById($id, $this->table);
       
        if ($result) {
            return $result;
        } else {
            return false;
        }

    }

// Notice Edit and Update method
    public function updateData($data, $file, $id){

        $class_routines_title = $this->fr->validation($data['class_routines_title']);

        $file_name = $this->fr->validation($file['class_routines_file']['name']);
        $file_type = $this->fr->validation($file['class_routines_file']['type']);
        $file_size = $this->fr->validation($file['class_routines_file']['size']);
        $file_location = $file['class_routines_file']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $permited = array('pdf', 'jpg', 'jpeg', 'png');

        $file_store = "upload/classRoutine/" . $unique_file;

        if (empty($class_routines_title)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        }
        if (!empty($file_name)) {
            if ($file_size > 10048567) {
                $this->msg = "File size must be less then 1 MB";
                return $this->msg;
            } elseif (in_array($file_exten, $permited) == false) {
                $this->msg = "you can upload only" . implode(', ', $permited);
                return $this->msg;
            } else {

                $this->unlinkFile($id);

                move_uploaded_file($file_location, $file_store);

                $result = $this->model->update($class_routines_title, $unique_file, $id, $this->table);

                if ($result) {
                    $this->msg = "Routine File Update successfull";
                    return $this->msg;
                } else {
                    $this->msg = "Routine File Update Failed";
                    return $this->msg;
                }
            }
        } else {

            $result = $this->model->update($class_routines_title, null, $id, $this->table);

            if ($result) {
                $this->msg = "Routine Update successfull";
                return $this->msg;
            } else {
                $this->msg = "Routine Update Failed";
                return $this->msg;
            }
        }
    }



    // Unlink file method
    public function unlinkFile($id){
        // select File from database
        $result = $this->model->selectById($id, $this->table);

        // unlink file
        if ($result) {
            while ($row = $result->fetch()) {
                $file = $row["class_routines_file"];
                unlink("upload/classRoutine/" . $file);
            }
        }
    }


    public function download($filename){
        // Check if the 'file' parameter is set in the URL
            if (isset($filename)) {
                // Get the filename from the URL parameter and sanitize it

                // Define the path to the directory where files are stored
                $fileDir = 'admin/upload/classRoutine/';

                // Construct the full path to the file
                $filePath = $fileDir . $filename;

                // Check if the file exists
                if (file_exists($filePath)) {
                    // Set headers for file download
                    header('Content-Description: File Transfer');
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename="' . $filename . '"');
                    header('Expires: 0');
                    header('Cache-Control: must-revalidate');
                    header('Pragma: public');
                    header('Content-Length: ' . filesize($filePath));

                    // Read the file and output it to the browser
                    readfile($filePath);
                    exit;
                } else {
                    // If the file does not exist, show an error message
                    die('File not found.');
                }
            } else {
                // If the 'file' parameter is not set in the URL, show an error message
                die('Invalid request.');
            }
                }



}
