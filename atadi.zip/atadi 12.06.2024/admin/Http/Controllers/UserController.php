<?php
require_once __DIR__ . "/../../Models/UserModel.php";

include_once __DIR__ . "/../Middleware/Format.php";




class UserController{

    private $model;

    private $table = 'tbl_users';     // change table name

    private $fr;
    
    public $msg;

    public function __construct() {
        $this->model = new UserModel();   // change model controller name

        $this->fr = new Format();
    }


    public function userCheck($data){
        $user_email = $this->fr->validation($data['user_email']);
        $user_password = $this->fr->validation($data['user_password']);

        return $this->model->checkUser($user_email, $user_password, $this->table);
    
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll($this->table);

        return $result ? $result : false;
    }

    public function displayUserRole($role){

        switch ( $role ) {
            case '1': 
                    $this->msg = 'Super Admin';
                    break;
            case '2' :
                    $this->msg = 'Admin';
                    break;
            case '3' :
                    $this->msg = 'User';
                    break;
            case '0' :
                    $this->msg = 'Panding User';
                    break;
                default:
                    $this->msg = 'You are not authorized';
        }
        return $this->msg;
    }

    public function displayUserStatus($status){

        switch ( $status ) {
            case '1': 
                    $this->msg = 'Active';
                    break;
            default:
                    $this->msg = 'Deactive';
        }
        return $this->msg;
    }


    // Add User 
    public function AddData($data){

        $user_name = $this->fr->validation($data['user_name']);
        $user_email = $this->fr->validation($data['user_email']);
        $user_password = $this->fr->validation($data['user_password']);

        if( empty($user_name) ) {
            $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Fields Must Not Be Empty ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }elseif(empty($user_email)){
            $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Email Fields is Also Empty ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }elseif(empty($user_password)){
            $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Password Fields Empty ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
        }else{
            // Email check if Email already Registration  
            $userEmailCheck = $this->checkEmail($user_email);

            if($userEmailCheck == true){
                $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
                This Email is already Registared. !! 
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>';
            }else{
                // PROCESS DATA AND SENT INTO DATABASE MODEL 
                $result = $this->model->insert($user_name, $user_email, $user_password, $this->table); // include variable name
            
                if ($result == true) {
                    $this->msg = '<div class="alert alert-success py-2 fs-4 alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill"></i> <strong> Successfully ! </strong> Registration ! 
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';
                    header("Location: user-login.php?");
                } else {
                    $this->msg = '<div class="alert alert-danger py-2 fs-4 alert-dismissible fade show" role="alert">
                    <i class="bi bi-x-circle-fill"></i> <strong> Failed ! </strong> Registration ! 
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>';  
                }
                return $this->msg;
            }
            return $this->msg; 
        }   
        return $this->msg;   
    }


    public function checkEmail($user_email){
        return $result = $this->model->emailCheck($user_email, $this->table);
    }


    public function getDataById($id){
        return $result = $this->model->selectById($id, $this->table);
    }



    // Notice Edit and Update method
    public function updateData($data, $id){

        $user_name = $this->fr->validation($data['user_name']);
        $user_email = $this->fr->validation($data['user_email']);
        $user_role = $this->fr->validation($data['user_role']);

        if (!empty($user_name) || !empty($user_email) || !empty($user_role) ) {

                $result = $this->model->update($user_name, $user_email, $user_role, $id, $this->table);

                if ($result) {
                    $this->msg = " User Update successfull";
                } else {
                    $this->msg = "User data Update Failed";
                }
                return $this->msg;
            } 
            
            return $result;   
        }

        // User Deactive
        public function deactiveUser($deactiveId){
            return $result = $this->model->userDeactiveUpdate($deactiveId, $this->table);
        }

        // User Active
        public function activeUser($activeId){
            return $result = $this->model->userActiveUpdate($activeId, $this->table);
        }


         // Data Delete
    public function deleteUserData($id){
        $result = $this->model->delete($id, $this->table);

        if ($result == true) {
            $this->msg = "User deleted successfully";
        } else {
            $this->msg = "User delete Failed";
        }

        return $this->msg;
    }


    public function checkPassword($id, $old_password){
        return $this->model->checkPass($id, $old_password, $this->table);
    
    }

    public function updatePassword($id, $data){

        $old_password = $this->fr->validation($data['old_password']);
        $new_password = $this->fr->validation($data['new_password']);

        if($old_password == "" || $new_password == ""){
            $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Fields Must Not Be Empty ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';   
            return $this->msg; 
        }

        $userPasswordCheck = $this->checkPassword($id, $old_password);


        if($userPasswordCheck == false){
            $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Old Password Does not Match ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>'; 
            return $this->msg;
        }
        
        if(strlen($new_password) < 6){
            $this->msg = '<div class="alert alert-info py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Password is Too Short ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>'; 
            return $this->msg;
        }


        // $new_password = md5($new_password);

        $result = $this->model->passUpdate($new_password, $id, $this->table);

        if ($result) {
            $this->msg = '<div class="alert alert-success py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Password Updated Succesfully ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>'; 
            return $this->msg;
        } else {
            $this->msg = '<div class="alert alert-danger py-2 fs-5 alert-dismissible fade show" role="alert">
            <i class="bi bi-x-circle-fill"></i> Password Updated Failed ! 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';;
            return $this->msg;
        }
        

        return $result;  
    } 
    
    
       



    
    
    
}


















?>