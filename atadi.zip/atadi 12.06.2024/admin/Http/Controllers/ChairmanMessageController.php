<?php

require_once __DIR__ . "/../../Models/ChairmanMessageModel.php";

include_once __DIR__ . "/../Middleware/Format.php";



class ChairmanMessageController
{

    public $model;

    public $table = 'tbl_chairman_message';     // change table name

    public $fr;
    
    public $msg;

    public function __construct()
    {
        $this->model = new ChairmanMessageModel();   // change model controller name

        $this->fr = new Format();
    }


    // Select all notice 
    public function showData(){

        $result = $this->model->selectAll($this->table);

        return $result ? $result : false;
    }

    // Add Notice 
    public function AddData($data, $file){

        $long_message = $this->fr->validation($data['long_message']);

        

        $file_name = $this->fr->validation($file['image_name']['name']);
        $file_type = $this->fr->validation($file['image_name']['type']);
        $file_size = $this->fr->validation($file['image_name']['size']);
        $file_location = $file['image_name']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $permited = array('jpg', 'jpeg', 'png', 'gif');

        $file_store = "upload/chairmanMessagePage/" . $unique_file;  // change folder name

        if (empty($file_name)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        } elseif ($file_size > 10048567) {
            $this->msg = "File size must be less then 1 MB";
            return $this->msg;
        } elseif (in_array($file_exten, $permited) == false) {
            $this->msg = "!! You Can Upload Only " . implode(', ', $permited) . " File";
            return $this->msg;
        } else {
            move_uploaded_file($file_location, $file_store);

            // PROCESS DATA AND SENT INTO DATABASE MODEL 
            $result = $this->model->insert($long_message, $unique_file, $this->table); // include variable name

            if ($result) {
                header('Location: message_of_chairman.php'); // change Redirect file name
                $this->msg = "Data Insert Succesfully";
            } else {
                $this->msg = "Data insert Failed";  
            }
            return $this->msg;
        }
    } // add notice method

   
    

    // Data Delete
    public function deleteData($id){

        // select unlink file from model
        $this->unlinkFile($id);

        // delete Data from model
        $result = $this->model->delete($id, $this->table);

        
        if ($result == true) {
            $this->msg = "Data deleted successfully";
            // return $this->msg;
        } else {
            $this->msg = "Data delete Failed";
            return $this->msg;
        }
    }
 

    public function getDataById($id){

        $result = $this->model->selectById($id, $this->table);
       
        return $result ? $result : false;

    }


// Data Edit and Update method
    public function updateData($data, $file, $id){

        $long_message = $this->fr->validation($data['long_message']);

        

        $file_name = $this->fr->validation($file['new_image']['name']);
        $file_type = $this->fr->validation($file['new_image']['type']);
        $file_size = $this->fr->validation($file['new_image']['size']);
        $file_location = $file['new_image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $permited = array('jpg', 'jpeg', 'png', 'gif');

        $file_store = "upload/chairmanMessagePage/" . $unique_file;  // change folder name

        
        if (!empty($file_name)) {
            if ($file_size > 10048567) {
                $msg = "File size must be less then 1 MB";
                return $msg;
            } elseif (in_array($file_exten, $permited) == false) {
                $msg = "you can upload only" . implode(', ', $permited);
                return $msg;
            } else {

                $this->unlinkFile($id);

                move_uploaded_file($file_location, $file_store);

                $result = $this->model->update($long_message, $unique_file, $id, $this->table);

                if ($result) {
                    $this->msg = "File and Data Update successfully";
                } else {
                    $this->msg = "File and Data Update Failed";
                }
            }
                return $this->msg;

        } else {
            $result = $this->model->update($long_message, null, $id, $this->table);

            if ($result) {
                $this->msg = "Data Update successfull";
            } else {
                $this->msg = "Data Update Failed";
            }
            return $this->msg;
        }
    }

    // Unlink file method
    public function unlinkFile($id){

        // select File from database
        $result = $this->model->selectById($id, $this->table);

        // unlink file
        if ($result) {
            while ($row = $result->fetch()) {
                $file = $row["image_name"];   // change column or file name
                unlink("upload/chairmanMessagePage/" . $file); // change folder name
            }
        }
    }



    public function limitWords($string, $limit) {
        // Split the string into an array of words
        $words = explode(" ", $string);
    
        // Check if the number of words in the string is greater than the limit
        if (count($words) > $limit) {
            // Slice the array to get only the desired number of words
            $words = array_slice($words, 0, $limit);
    
            // Join the sliced words back into a string
            $string = implode(" ", $words) . " .... "; // add ellipsis to indicate there are more words
        }
    
        return $string;
    }




}
