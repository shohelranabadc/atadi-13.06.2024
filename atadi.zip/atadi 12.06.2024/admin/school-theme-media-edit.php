<?php

include __DIR__ . '/../vendor/autoload.php';

$SchoolMediaCon = new SchoolMediaController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $UpdateMessage = $SchoolMediaCon->updateData($_POST, $_FILES, $Eid);
    
}



    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">School Theme Media</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                            
                                <?php 
                                    if(isset($UpdateMessage)){ ?>

                                            <?php echo $UpdateMessage; ?>

                                    <?php } ?>
                            
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">হোম পেজের স্লাইডার ছবি নির্বাচন করুন</h4>
                                        <?php
                                        $results = $SchoolMediaCon->getDataById($Eid);
                                        if ($results) {
                                            foreach ($results as $row){ ?>

                                        <form action="" method="POST" enctype="multipart/form-data">

                                            <div class="row">
                                               <div class="mb-3 col-lg-3">
                                                    <label class="form-label">Logo Name</label>
                                                    <input class="form-control" name="new_logo_name" value="<?php echo $row['logo_name'] ;?>" type="text" placeholder="ছবির নাম দিন">
                                                </div>

                                                <div class="mb-3 col-lg-2">
                                                    <label class="form-label">Order Number</label>
                                                    <input class="form-control" name="new_order_number" value="<?= $row['order_number'] ?>" type="text">
                                                </div>
                                            </div>

                                        <img src="upload/schoolThemeMedia/<?= $row['logo']?>" alt="" width="150" height="150">
                                        <br><br>
                                            <div class="col-md-6">
                                                <div class="input-group mb-3">
                                                    <input type="file" onchange="ImgShow(event)" class="form-control" name="new_image" id="inputGroupFile02"> 
                                                    <label class="input-group-text" for="inputGroupFile02"><i class="fa-solid fa-plus"></i></label>
                                                </div>
                                                <img id="output" src="./assets/demoImage.jpg" alt="" width="150" height="150">
                                            </div>
                                            <div class="mt-4">
                                                <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                            </div>
                                        </form>
                                        <?php } } ?>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>

                        <hr>

                        
                        

                       

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->


                <script>
                    function ImgShow(event) {
                        var img = document.getElementById("output");
                        img.src = URL.createObjectURL(event.target.files[0]);
                    };
    </script>


<?php
    include_once 'inc/footer.php';

?>