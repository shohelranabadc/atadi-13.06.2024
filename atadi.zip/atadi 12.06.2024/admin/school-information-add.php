<?php

include __DIR__ . '/../vendor/autoload.php';

$schoolInforCon = new SchoolInformationController();

// CSRF token generation

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
        // Validate form inputs and files here
        $schoolInfoAdd = $schoolInforCon->AddData($_POST);
}

include_once 'inc/header.php';
include_once 'inc/sidebar.php';
?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">Add School Information</h4>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <?php if (isset($schoolInfoAdd)) { ?>
                        <?= $schoolInfoAdd; ?>
                    <?php } ?>

                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">School Information Form</h4>
                            <form class="repeater" method="POST" enctype="multipart/form-data">
                                
                                
                                <div class="row">
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label">School Name (Bangla)</label>
                                        <input class="form-control" name="school_name_bangla" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label">School Name (English)</label>
                                        <input class="form-control" name="school_name_english" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="resume">School Village Name</label>
                                        <input class="form-control" name="school_village_name" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">School Post Name</label>
                                        <input class="form-control" name="school_post_name" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">School Police Station</label>
                                        <input class="form-control" name="school_police_station" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="name">School District Name</label>
                                        <input class="form-control" name="school_district_name" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label">School MPO Code</label>
                                        <input class="form-control" name="school_mpo_code" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label">School EIIN Number</label>
                                        <input class="form-control" name="school_eiin_number" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">School Establishment Date</label>
                                        <input class="form-control" name="school_establishment_date" type="text">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">School Email Address</label>
                                        <input class="form-control" name="school_email_address" type="email">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">School Mobile Number</label>
                                        <input class="form-control" name="school_mobile_number" type="tel">
                                    </div>
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">School Location URL (map)</label>
                                        <input class="form-control" name="school_location_url" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="mb-3 col-lg-3">
                                        <label class="form-label" for="message">Copy Right Starting Date</label>
                                        <input class="form-control" name="copy_right_date" type="text">
                                    </div>
                                </div>
                                <div class="mt-4">
                                    <button type="submit" class="btn btn-success waves-effect waves-light" name="save_btn">
                                        <i class="bi bi-plus me-1"></i>Save
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include_once 'inc/footer.php';
?>
