<?php
include __DIR__ . '/../vendor/autoload.php';

$userCon = new UserController();

if(isset($_GET['passId'])){
    $passId = base64_decode($_GET['passId']); 
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_POST['update']) && isset($passId)) {
    $updatePass = $userCon->updatePassword($passId, $_POST);
}

?>



<!-- including header and sidebar -->
<?php

include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>

    <body class="authentication-bg mt-5">
        <div class="account-pages my-3 pt-sm-5">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                    <?php
                        if(isset($updatePass)){?>
                            <?= $updatePass; ?>
                    <?php } ?>
                        <div class="card">
                            <div class="card-body p-4"> 
                                <div class="text-center mt-2">
                                    <h5 class="text-primary">Change Password !</h5>
                                </div>
                                <div class="p-2 mt-3">
                                <form action="" method="POST">
        
                                        <div class="mb-3">
                                            <label class="form-label" for="old-password">Old Password</label>
                                            <input type="password" class="form-control" id="old-password"  name="old_password" placeholder="Enter password">
                                        </div>
                
                                        <div class="mb-3">
                                            <label class="form-label" for="new-password">New Password</label>
                                            <input type="password" class="form-control" id="new-password"  name="new_password" placeholder="Enter password">
                                        </div>
                                            
                                        <div class="mt-3 text-end">
                                            <button class="btn btn-primary w-sm waves-effect waves-light" name="update" type="submit">Update Password</button>
                                        </div>
                                    </form>
                                </div>
            
                            </div>
                        </div>

                      

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>

<?php include_once 'inc/footer.php'; ?>