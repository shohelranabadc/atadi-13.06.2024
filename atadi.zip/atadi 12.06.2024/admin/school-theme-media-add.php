<?php

include __DIR__ . '/../vendor/autoload.php';

$SchoolMediaCon = new SchoolMediaController();

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $SchoolMediaCon->AddData($_POST, $_FILES);
}


include_once 'inc/header.php';
include_once 'inc/sidebar.php';

?>



<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="mb-0">School Theme Media Add</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">ছবি নির্বাচন করুন</h4>
                            <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="mb-3 col-lg-4">
                                            <input class="form-control" type="file" name="logo">
                                        </div>
                                        <div class="mb-3 col-lg-3">
                                            <input class="form-control" name="logo_name" type="text" placeholder="ছবির নাম দিন">
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="collapse show" id="filtersizes-collapse">
                                                        <div class="">
                                                            <div class="d-flex align-items-center">
                                                                <div class="flex-grow-1">
                                                                    <h5 class="font-size-15 mb-0">ছবির অর্ডার নম্বর</h5>
                                                                </div>
                                                                <div class="w-xs">
                                                                    <select name="order_number" class="form-select">
                                                                        <option>Select</option>
                                                                        <option value="1">1</option>
                                                                        <option value="2">2</option>
                                                                        <option value="3">3</option>
                                                                        <option value="4">4</option>
                                                                        <option value="5">5</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                <div class="mt-4">
                                    <a href="school-theme-media" class="btn btn-info w-md">back</a>
                                    <button type="submit" class="btn btn-primary w-md" name="add_btn">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>

            <hr>



        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


    <?php
    include_once 'inc/footer.php';

    ?>