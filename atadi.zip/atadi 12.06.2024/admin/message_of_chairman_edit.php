<?php
include __DIR__ . '/../vendor/autoload.php';

$chairmanMessageCon = new ChairmanMessageController();

if (isset($_GET['Eid'])) {
    $Eid = base64_decode($_GET['Eid']);
}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $chairmanMessageUpdate = $chairmanMessageCon->updateData($_POST, $_FILES, $Eid);
    
}


    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0">স্বাগতম বিবরণ লিখুন</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                            <span>
                                <?php 
                                    if(isset($chairmanMessageUpdate)){
                                                                ?>
                                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                            <?php echo $chairmanMessageUpdate; ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                        </div>
                                    <?php
                                }
                    
                                ?>
                            </span>
                                <div class="card">
                                    <div class="card-body">
                                    <?php
                                    $results = $chairmanMessageCon->getDataById($Eid);
                                    if ($results) {
                                    foreach ($results as $row){ ?>
                                        <form action="" method="POST" enctype="multipart/form-data">
                                            
                                            <img src="./upload/chairmanMessagePage/<?php echo $row['image_name']?>" alt="" width="150" height="150">
                                            <br><br>
                                            <div class="col-md-10">
                                                <div class="input-group mb-3">
                                                    <input type="file" onchange="ImgShow(event)" class="form-control" name="new_image" id="inputGroupFile02"> 
                                                    <label class="input-group-text" for="inputGroupFile02"><i class="fa-solid fa-plus"></i></label>
                                                </div>
                                                <img id="output" src="./assets/demoImage.jpg" alt="" width="150" height="150">
                                            </div>
                                            

                                            <div class="col-md-10">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <h4 class="card-title">বিস্তারিত বিবরণ</h4>
                                                        <textarea name="long_message" id="classic-editor-two" cols="30" rows="10">
                                                            <?php echo $row['long_message'];?>
                                                        </textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mt-4">
                                                <button type="submit" class="btn btn-primary w-md" name="update_btn">Update</button>
                                            </div>
                                        </form>
                                        <?php } } ?>
                                    </div>
                                </div>
                            </div> <!-- end col -->
                        </div>

                        <hr>

                       
                        

                       

                       


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <script>
                    function ImgShow(event) {
                        var img = document.getElementById("output");
                        img.src = URL.createObjectURL(event.target.files[0]);
                    };
                </script>

<?php
    include_once 'inc/footer.php';

?>