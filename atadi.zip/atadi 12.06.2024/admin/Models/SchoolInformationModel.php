<?php

require_once __DIR__ . "/../../config/Database.php";
include_once __DIR__ . "/../Http/Middleware/Format.php";

class SchoolInformationModel {

    private $db;

    private $fr;

    private $table = 'tbl_school_info';

    public function __construct() {
        $this->db = new Database();
        $this->fr = new Format();
    }

    // Select All Data
    public function selectAll() {
        $sql = "SELECT * FROM $this->table";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
       return $result;
    }

    // Select All Data
    public function selectSingleRow() {
        $sql = "SELECT * FROM $this->table";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
       return $result;
    }

    // Select By Id 
    public function selectById($id) {
        $sql = "SELECT * FROM $this->table WHERE id = :id";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Insert Data
    public function insert($data) {
        try {
            $school_name_bangla = $this->fr->validation($data['school_name_bangla']);
            $school_name_english = $this->fr->validation($data['school_name_english']);
            $school_village_name = $this->fr->validation($data['school_village_name']);
            $school_post_name = $this->fr->validation($data['school_post_name']);
            $school_police_station = $this->fr->validation($data['school_police_station']);
            $school_district_name = $this->fr->validation($data['school_district_name']);
            $school_mpo_code = $this->fr->validation($data['school_mpo_code']);
            $school_eiin_number = $this->fr->validation($data['school_eiin_number']);
            $school_establishment_date = $this->fr->validation($data['school_establishment_date']);
            $school_email_address = $this->fr->validation($data['school_email_address']);
            $school_mobile_number = $this->fr->validation($data['school_mobile_number']);
            $school_location_url = $this->fr->validation($data['school_location_url']);
            $copy_right_date = $this->fr->validation($data['copy_right_date']);
        
           
            $sql = "INSERT INTO $this->table (
                school_name_bangla, school_name_english, school_village_name, 
                school_post_name, school_police_station, school_district_name, 
                school_mpo_code, school_eiin_number, school_establishment_date, 
                school_email_address, school_mobile_number, school_location_url, copy_right_date
            ) VALUES (
                :school_name_bangla, :school_name_english, :school_village_name, 
                :school_post_name, :school_police_station, :school_district_name, 
                :school_mpo_code, :school_eiin_number, :school_establishment_date, 
                :school_email_address, :school_mobile_number, :school_location_url, :copy_right_date
            )";

            $stmt = $this->db->conn->prepare($sql);

            $stmt->bindParam(':school_name_bangla', $school_name_bangla);
            $stmt->bindParam(':school_name_english', $school_name_english);
            $stmt->bindParam(':school_village_name', $school_village_name);
            $stmt->bindParam(':school_post_name', $school_post_name);
            $stmt->bindParam(':school_police_station', $school_police_station);
            $stmt->bindParam(':school_district_name', $school_district_name);
            $stmt->bindParam(':school_mpo_code', $school_mpo_code);
            $stmt->bindParam(':school_eiin_number', $school_eiin_number);
            $stmt->bindParam(':school_establishment_date', $school_establishment_date);
            $stmt->bindParam(':school_email_address', $school_email_address);
            $stmt->bindParam(':school_mobile_number', $school_mobile_number);
            $stmt->bindParam(':school_location_url', $school_location_url);
            $stmt->bindParam(':copy_right_date', $copy_right_date);
            
            
            $stmt->execute();

            return $this->successMessage("Data Insert successfully.");
        } catch (Exception $e) {
            return $this->errorMessage("Data Insert failed: " . $e->getMessage());
        }
            
            
    }

    // Update Data
    public function update($data, $id) {
        try {
            $school_name_bangla = $this->fr->validation($data['school_name_bangla']);
            $school_name_english = $this->fr->validation($data['school_name_english']);
            $school_village_name = $this->fr->validation($data['school_village_name']);
            $school_post_name = $this->fr->validation($data['school_post_name']);
            $school_police_station = $this->fr->validation($data['school_police_station']);
            $school_district_name = $this->fr->validation($data['school_district_name']);
            $school_mpo_code = $this->fr->validation($data['school_mpo_code']);
            $school_eiin_number = $this->fr->validation($data['school_eiin_number']);
            $school_establishment_date = $this->fr->validation($data['school_establishment_date']);
            $school_email_address = $this->fr->validation($data['school_email_address']);
            $school_mobile_number = $this->fr->validation($data['school_mobile_number']);
            $school_location_url = $this->fr->validation($data['school_location_url']);
            $copy_right_date = $this->fr->validation($data['copy_right_date']);

       
                $sql = "UPDATE $this->table SET 
                    school_name_bangla = :school_name_bangla,
                    school_name_english = :school_name_english,
                    school_village_name = :school_village_name,
                    school_post_name = :school_post_name,
                    school_police_station = :school_police_station,
                    school_district_name = :school_district_name,
                    school_mpo_code = :school_mpo_code,
                    school_eiin_number = :school_eiin_number,
                    school_establishment_date = :school_establishment_date,
                    school_email_address = :school_email_address,
                    school_mobile_number = :school_mobile_number,
                    school_location_url = :school_location_url,
                    copy_right_date = :copy_right_date
                    WHERE id = :id";
            

            $stmt = $this->db->conn->prepare($sql);

            
           
            $stmt->bindParam(':school_name_bangla', $school_name_bangla);
            $stmt->bindParam(':school_name_english', $school_name_english);
            $stmt->bindParam(':school_village_name', $school_village_name);
            $stmt->bindParam(':school_post_name', $school_post_name);
            $stmt->bindParam(':school_police_station', $school_police_station);
            $stmt->bindParam(':school_district_name', $school_district_name);
            $stmt->bindParam(':school_mpo_code', $school_mpo_code);
            $stmt->bindParam(':school_eiin_number', $school_eiin_number);
            $stmt->bindParam(':school_establishment_date', $school_establishment_date);
            $stmt->bindParam(':school_email_address', $school_email_address);
            $stmt->bindParam(':school_mobile_number', $school_mobile_number);
            $stmt->bindParam(':school_location_url', $school_location_url);
            $stmt->bindParam(':copy_right_date', $copy_right_date);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);

            $stmt->execute();
              
     return $this->successMessage("Data Update successfully.");
        } catch (Exception $e) {
            return $this->errorMessage("Data Update failed: " . $e->getMessage());
        } 

    }

    // Delete Data
    public function delete($id) {
        try {
            
            $sql = "DELETE FROM $this->table WHERE id = :id";
            $stmt = $this->db->conn->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $this->successMessage("Data deleted successfully.");
        } catch (Exception $e) {
            return $this->errorMessage("Data deletion failed: " . $e->getMessage());
        }
    }

    


    // Success Message
    private function successMessage($message) {
        return '<div class="alert alert-success py-2 fs-4 alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle-fill"></i> ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
    }

    // Error Message
    private function errorMessage($message) {
        return '<div class="alert alert-danger py-2 fs-4 alert-dismissible fade show" role="alert">
                <i class="bi bi-x-circle-fill"></i> ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>';
    }




   

    
}
?>
