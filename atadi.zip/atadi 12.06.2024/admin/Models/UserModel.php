<?php

require_once __DIR__ . "/../../config/Database.php";

class UserModel{

    public $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function checkUser($email, $password, $table){
        $user_email = $email;
        $user_password = $password;

        $sql = "SELECT * FROM $table WHERE user_email = :user_email AND user_password = :user_password";

        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([
            ':user_email' => $user_email,
            ':user_password' => $user_password
        ]);

        return $result = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Select All Data
    public function selectAll($table){

        $sql = "SELECT * FROM $table ORDER BY user_role ASC ";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();

       $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

       return $result;
    }


    // Insert Query
    public function insert($user_name, $user_email, $user_password, $table){

        // DATA INSERT INTO DATABASE TABLE QUERY
        $sql = "INSERT INTO $table (user_name, user_email, user_password) 
                VALUES (:user_name, :user_email, :user_password)";

        // Notice Insert Execution 
        $stmt = $this->db->conn->prepare($sql);

        $stmt->bindParam(':user_name', $user_name);
        $stmt->bindParam(':user_email', $user_email);
        $stmt->bindParam(':user_password', $user_password);

        $stmt->execute();
            
        return $stmt;

    }

    public function emailCheck($email, $table){
        $user_email = $email;

        $sql = "SELECT * FROM $table WHERE user_email = :user_email";

        $stmt = $this->db->conn->prepare($sql);

        $stmt->bindParam(':user_email', $user_email);

        $stmt->execute();

        if($stmt->rowCount() > 0){
            return true;
        }else{
            return false;
        }
    }


    // Select By Id 
    public function selectById($id, $table){

        $sql = "SELECT * FROM $table WHERE user_id = :id";
        
        $stmt = $this->db->conn->prepare($sql);

        // Bind the parameter
        $stmt->bindParam(':id', $id);

        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);

    }

// Update Query
public function update($user_name, $user_email, $user_role, $id, $table){

        // DATA update INTO DATABASE TABLE QUERY
        $sql = "UPDATE $table SET user_name = :user_name, 
                                    user_email = :user_email,  
                                    user_role = :user_role
                                    WHERE user_id = :id";

        // Notice Insert Execution 
        $stmt = $this->db->conn->prepare($sql);

        $stmt->bindParam(':user_name', $user_name);
        $stmt->bindParam(':user_email', $user_email);
        $stmt->bindParam(':user_role', $user_role);
        $stmt->bindParam(':id', $id);

        $stmt->execute();

        return $stmt;
   
    }

   public function userDeactiveUpdate($deactiveId, $table){

            $sql = "UPDATE $table SET user_status = '1'  WHERE user_id = :id";

            $stmt = $this->db->conn->prepare($sql);

             $stmt->bindParam(':id', $deactiveId);

             $stmt->execute();

        return $stmt;
   }

   public function userActiveUpdate($activeId, $table){

    $sql = "UPDATE $table SET user_status = '0'  WHERE user_id = :id";

    $stmt = $this->db->conn->prepare($sql);

     $stmt->bindParam(':id', $activeId);

     $stmt->execute();

    return $stmt;
}



// Delete Query
public function delete($id, $table){

    $sql = "DELETE FROM $table WHERE user_id = :id";
    $stmt = $this->db->conn->prepare($sql);

    $stmt->execute([':id' => $id]);

    return $stmt;
}
    
public function checkPass($id, $old_password, $table){
    $old_password = $old_password;

    $sql = "SELECT user_password FROM $table WHERE user_id = :id && user_password = :user_password";

    $stmt = $this->db->conn->prepare($sql);

    $stmt->bindParam(':id', $id);
    $stmt->bindParam(':user_password', $old_password);

    $stmt->execute();

    if($stmt->rowCount() > 0){
        return true;
    }else{
        return false;
    }
}



public function passUpdate($new_password, $id, $table){
    $sql = "UPDATE $table SET user_password = :user_password  WHERE user_id = :id";

    $stmt = $this->db->conn->prepare($sql);

     $stmt->bindParam(':id', $id);
     $stmt->bindParam(':user_password', $new_password);

     $stmt->execute();

    return $stmt;
}


}








?>