<?php

require_once __DIR__ . "/../../config/Database.php";

class ImportantLinkModel{

    public $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    
    // Select All Data
    public function selectAll($table){

        $sql = "SELECT * FROM $table ORDER BY id DESC";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();

       $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

       return $result;
    }


    // Select By Id 
    public function selectById($id, $table){

        $sql = "SELECT * FROM $table WHERE id = :id";
        
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([':id' => $id]);

        return $stmt;
    }

    // Insert Query
    public function insert($url_link, $url_title, $table){

        // DATA INSERT INTO DATABASE TABLE QUERY
        $sql = "INSERT INTO $table (url_link, url_title) 
                VALUES (:url_link, :url_title)";

        // Notice Insert Execution 
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([
            ':url_link' => $url_link, 
            ':url_title' => $url_title]);

        return $stmt;

    }

    // Update Query
    public function update($url_link, $url_title, $id, $table){

        
            // DATA update INTO DATABASE TABLE QUERY
            $sql = "UPDATE $table SET url_link = :url_link, 
                                      url_title = :url_title 
                                       WHERE id = :id";

            // Notice Insert Execution 
            $result = $this->db->conn->prepare($sql);

            $result->execute([':url_link' => $url_link, 
                              ':url_title' => $url_title,
                              ':id' => $id]);

            return $result;

    }


    // Delete Query
    public function delete($id, $table){

        $sql = "DELETE FROM $table WHERE id = :id";
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([':id' => $id]);

        return $stmt;
    }

}



?>