<?php

require_once __DIR__ . "/../../config/Database.php";
include_once __DIR__ . "/../Http/Middleware/Format.php";

class SchoolMediaModel{

    public $db;

    public $fr;

    public $table = 'atadi_school_media_table';

    public function __construct() {

        $this->db = new Database();
        $this->fr = new Format();

    } 
    // Select All Data
    public function selectAll(){

        $sql = "SELECT * FROM $this->table";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();

       $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

       return $result;
    }


    // Select By Id 
    public function selectById($id){

        $sql = "SELECT * FROM $this->table WHERE id = :id";
        
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([':id' => $id]);

        return $stmt;
    }

    // Insert Query
    public function insert($data, $file){

        // $sanitizedData = $this->sanitizeData($data);

        $logo_name = $this->fr->validation($data['logo_name']);
        $order_number = $this->fr->validation($data['order_number']);



        $file_name = $this->fr->validation($file['logo']['name']);
        $file_type = $this->fr->validation($file['logo']['type']);
        $file_size = $this->fr->validation($file['logo']['size']);
        $file_location = $file['logo']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;
        $permited = array('jpg', 'jpeg', 'png', 'gif');
        $file_store = "upload/schoolThemeMedia/" . $unique_file;  // change folder name

        if (empty($file_name)) {
            $this->msg = "Filds Must not be empty";
            return $this->msg;
        } elseif ($file_size > 10048567) {
            $this->msg = "File size must be less then 1 MB";
            return $this->msg;
        } elseif (in_array($file_exten, $permited) == false) {
            $this->msg = "!! You Can Upload Only " . implode(', ', $permited) . " File";
            return $this->msg;
        } else {
            move_uploaded_file($file_location, $file_store);

            $sql = "INSERT INTO $this->table (logo, logo_name, order_number) 
                                    VALUES (:logo, :logo_name, :order_number)";

            $stmt = $this->db->conn->prepare($sql);

            $stmt->bindParam(':logo', $unique_file);
            $stmt->bindParam(':logo_name', $logo_name);
            $stmt->bindParam(':order_number', $order_number);

         
            return $stmt->execute();

           

        }

    }

    // Update Query
    public function update($data, $file, $id){

        
        $new_logo_name = $this->fr->validation($data['new_logo_name']);
        $new_order_number = $this->fr->validation($data['new_order_number']);


        // Those file are permited to update or add
        $permited = array('jpg', 'jpeg', 'png', 'gif');            // File extention also change if needed

        $file_name = $this->fr->validation($file['new_image']['name']);
        $file_type = $this->fr->validation($file['new_image']['type']);
        $file_size = $this->fr->validation($file['new_image']['size']);
        $file_location = $file['new_image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_exten = strtolower(end($div));
        $unique_file = substr(md5(time()), 0, 10) . '.' . $file_exten;

        $file_store = "upload/schoolThemeMedia/" . $unique_file;  // change folder name

    

        if (!empty($file_name)) {
            if ($file_size > 10048567) {
                $this->msg = "File size must be less then 1 MB";
                return $this->msg;
            } elseif (in_array($file_exten, $permited) == false) {
                $this->msg = "you can upload only " . implode(', ', $permited);
                return $this->msg;
            } else {

                $this->unlinkFile($id);

                move_uploaded_file($file_location, $file_store);
                    // DATA update INTO DATABASE TABLE QUERY
                    $sql = "UPDATE $this->table SET 
                                              logo = :logo, 
                                              logo_name = :logo_name, 
                                              order_number = :order_number
                                              WHERE id = :id";
        
                    // Notice Insert Execution 
                    $stmt = $this->db->conn->prepare($sql);

                    $stmt->bindParam(':logo', $unique_file);
                    $stmt->bindParam(':logo_name', $new_logo_name);
                    $stmt->bindParam(':order_number', $new_order_number);
                    $stmt->bindParam(':id', $id);
        
                    $stmt->execute();
        

                    if ($stmt) {
                        return $this->msg = '<div class="alert alert-success py-2 fs-4 alert-dismissible fade show" role="alert">
                                                <i class="bi bi-check-circle-fill"></i> Data and Image Updated Successfully!
                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                            </div>';
                    } else {
                        return $this->msg = '<div class="alert alert-danger py-2 fs-4 alert-dismissible fade show" role="alert">
                                                    <i class="bi bi-x-circle-fill"></i> <strong>Data!</strong> not updated !
                                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                            </div>';
                    }
            }
        } else {
                        // DATA update INTO DATABASE TABLE QUERY
                        $sql = "UPDATE $this->table SET logo_name = :logo_name, 
                                                        order_number = :order_number
                                                        WHERE id = :id";
            
                        // Notice Insert Execution 
                        $stmt = $this->db->conn->prepare($sql);
    
                        $stmt->bindParam(':logo_name', $new_logo_name);
                        $stmt->bindParam(':order_number', $new_order_number);
                        $stmt->bindParam(':id', $id);
            
                        $stmt->execute();
            
                        

                        if ($stmt) {
                            return $this->msg = '<div class="alert alert-success py-2 fs-4 alert-dismissible fade show" role="alert">
                                                    <i class="bi bi-check-circle-fill"></i> Data Updated Successfully!
                                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                </div>';
                        } else {
                            return $this->msg = '<div class="alert alert-danger py-2 fs-4 alert-dismissible fade show" role="alert">
                                                        <i class="bi bi-x-circle-fill"></i> <strong>Data!</strong> not updated !
                                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                </div>';
                        }
                    
                }
        
    }


    // Delete Query
    public function delete($id){

        $sql = "DELETE FROM $this->table WHERE id = :id";
        $stmt = $this->db->conn->prepare($sql);

        $stmt->bindParam(':id', $id);
        $stmt->execute();

        return $stmt;
    }

    
    // Unlink file method
    public function unlinkFile($id){

        // select unlink file from model
        $result = $this->selectById($id);

        // unlink notice file
        if ($result) {
            while ($row = $result->fetch()) {
                $file = $row["logo"];   // change column or file name
                unlink("upload/schoolThemeMedia/" . $file); // change folder name
            }
        }
    }




}


?>