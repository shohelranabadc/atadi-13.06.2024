<?php

require_once __DIR__ . "/../../config/Database.php";

class HeadmasterMessageModel{

    public $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    
    // Select All Data
    public function selectAll($table){

        $sql = "SELECT * FROM $table ORDER BY id DESC";
        $stmt = $this->db->conn->prepare($sql);
        $stmt->execute();

       $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

       return $result;
    }


    // Select By Id 
    public function selectById($id, $table){

        $sql = "SELECT * FROM $table WHERE id = :id";
        
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([':id' => $id]);

        return $stmt;
    }

    // Insert Query
    public function insert($long_message, $unique_file, $table){

        // DATA INSERT INTO DATABASE TABLE QUERY
        $sql = "INSERT INTO $table (long_message, image_name) 
                VALUES (:long_message, :unique_file)";

        // Notice Insert Execution 
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([ 
            ':long_message' => $long_message, 
            ':unique_file' => $unique_file]);

        return $stmt;

    }

    // Update Query
    public function update($long_message, $unique_file, $id, $table){

        if($unique_file){
            // DATA update INTO DATABASE TABLE QUERY
            $sql = "UPDATE $table SET long_message = :long_message, 
                                      image_name = :unique_file WHERE id = :id";

            // Notice Insert Execution 
            $result = $this->db->conn->prepare($sql);

            $result->execute([':long_message' => $long_message,
                              ':unique_file' => $unique_file, 
                              ':id' => $id]);

            return $result;
        }else {
             // DATA update INTO DATABASE TABLE QUERY
             $sql = "UPDATE $table SET long_message = :long_message 
                                        WHERE id = :id";
             // Notice Insert Execution 
             $result = $this->db->conn->prepare($sql);
 
             $result->execute([':long_message' => $long_message,
                              ':id' => $id]);

             return $result;
        }
        
    }


    // Delete Query
    public function delete($id, $table){

        $sql = "DELETE FROM $table WHERE id = :id";
        $stmt = $this->db->conn->prepare($sql);

        $stmt->execute([':id' => $id]);

        return $stmt;
    }

}








?>