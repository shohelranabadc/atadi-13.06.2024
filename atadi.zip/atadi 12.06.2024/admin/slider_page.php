<?php

include __DIR__ . '/../vendor/autoload.php';

$sliderCon = new SliderController();

if(isset($_GET['delid'])){
    $id = base64_decode($_GET['delid']);
    $deleteImage = $sliderCon->deleteData($id);
}


    include_once 'inc/header.php';
    include_once 'inc/sidebar.php';

?>
            
            

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row mt-3">
                            <div class="col-10">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h1 class="mb-0">Slider Image</h1>
                                    <a href="slider_add.php" class="btn btn-primary">Add Image</a>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        

                        <div class="row">
                            <div class="col-12">
                            <span>
                        <?php
                        if (isset($sliderCon->msg)) {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <?= $sliderCon->msg; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        }

                        ?>
                    </span>
                                <table class="table">
                                    <thead>
                                        <th>Id</th>
                                        <th>Image name</th>
                                        <th>Image</th>
                                        <th>Edit | Delete</th>
                                        
                                    </thead>
                                    <tbody>
                        <?php

                        $results = $sliderCon->showData();
                        
                        $count = 1;
                        if ($results) {
                            foreach ($results as $row){ ?>

                          <tr>
                            <td><?php echo $count++?></td>
                            <td><?php echo $row['slider_image_name'] ;?></td>
                            <td><img src="./upload/sliderImage/<?= $row['slider_image_name']; ?>" width="100" alt=""></td>
                            <td>
                                <a href="slider_edit.php?Eid=<?=base64_encode($row['id']);?>">
                                    <button type="button" name="edit_btn" class="btn btn-primary"><i class="bi bi-pencil-square"></i></button>
                                </a>

                                <a onclick="return confirm('Are you sure to Delete')" href="?delid=<?=base64_encode($row['id']);?>">
                                    <button name="delete_btn" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                                </a>
                            </td>
                          </tr>
                           
                        <?php }
                        } else {
                            echo "<div class='text-center'>
                                <span class='text-danger h2'>No Slider Image is Found </span>
                            </div>";
                        }
                        
                        ?>

                 
                </tbody>
               </table>
            </div>
        </div>
    </div> <!-- container-fluid -->
</div>
                <!-- End Page-content -->


<?php
    include_once 'inc/footer.php';

?>