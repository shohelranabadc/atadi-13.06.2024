<?php 

  

    class Database{

        public $db_name = "mysql:host=localhost;dbname=atadi";
        public $username = "root";
        public $password = '';

        public $conn;
        public $error;


        public function __construct()
        {
            $this->dbConnect();
            
        }

        public function dbConnect(){
            $this->conn = new PDO($this->db_name, $this->username,  $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            if(!$this->conn){
                $this->error = "Database Connection Failed";
                return false;
            }
        }
       
    }

    

?>