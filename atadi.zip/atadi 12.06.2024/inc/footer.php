<?php include 'vendor/autoload.php';?>
 <!-- START FOOTER SECTION -->
 <footer>
            <div class="container px-0">
                <!-- TOP FOOTER START -->
                <div class="top-footer-section">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="footer-logo-container">
                      <?php 
                          $schoolMediaCon = new SchoolMediaController();
                          $result = $schoolMediaCon->showData();  
                      ?>
                        <div class="logo"><a href="/"><img src="admin/upload/schoolThemeMedia/<?= $result[0]['logo'] ?>" alt="atadi high school" class="img-fluid"></a></div>
                      </div>
                      <?php 
                          $schoolInfoCon = new SchoolInformationController();
                          $row = $schoolInfoCon->singleRow();  
                      ?>
                      <div class="footer-partOne-text text-white">
                        <p><?= $row['school_name_bangla']?></p>
                        <br/>
                        <p class="text-warning">ডাকঘর- <?= $row['school_post_name']?> </p>
                        <p class="text-warning">উপজেলা- <?= $row['school_police_station']?></p>
                        <p class="text-warning">জেলা- <?= $row['school_district_name']?> </p>
                        <br/>
                        <p>মোবাইল : <?= $row['school_mobile_number']?></p> 
                        <p>ইমেইল- <?= $row['school_email_address']?></p>
                      </div>

                      <!-- SOCIAL MEDIA LINK STAR -->
                      <div class="social-link-container">
                        <ul class="socialList">
                          <li><a href="https://www.facebook.com/atadischool/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                          <li><a href="https://twitter.com/?lang=en" target="_blank"><i class="fa fa-twitter"></i></a></li>
                          <li><a href="https://mail.google.com/" target="_blank"><i class="fa fa-envelope"></i></a></li>
                          <li><a href="https://web.whatsapp.com/" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
                        </ul>
                      </div>
                      <!-- SOCIAL MEDIA LINK END -->

                    </div>
                    <div class="col-lg-4">
                      <div class="footer-partSecound-text text-white">
                        <p>জরুরী লিংকসমুহ</p>
                        <div class="emergency-link">
                          <ul>    
                            <?php
                                $importantLinkCon = new ImportantLinkController();
                                $results = $importantLinkCon->showData();
         
                                if ($results) {
                                  foreach ($results as $row){ ?>
                                        <li>
                                            <a target="_blank" href="<?= $row['url_link']; ?>"><?= $row['url_title']; ?></a>
                                        </li>
                            <?php } 
                                  } else {
                                    echo "<span class='text-danger'>No Important Link Found </span>";
                                  } ?>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="footer-partThird-text text-white">
                        <p>আমাদের অবস্থান</p>
                      </div>
                      <?php 
                          $schoolInfoCon = new SchoolInformationController();
                          $row = $schoolInfoCon->singleRow();  
                      ?>
                      <div class="school-location">
                        <iframe src="<?= $row['school_location_url']; ?>" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                      </div>
                      
                    </div>
                  </div>
                </div>
                <!-- TOP FOOTER END -->

                <!-- BOOTOM FOOTER START -->
                <div class="bottom-footer school_header_bg">
                  <div class="row">
                  <div class="col-lg-5">
                      <div class="bottom-footer-start">
                            <p>Copyright © <?= $row['copy_right_date']; ?> - <script>document.write(new Date().getFullYear())</script> &nbsp<a href="#"><?= strtoupper($row['school_name_english']); ?></a> &nbsp All Right Reserved</p>
                      </div>
                  </div>
                  <div class="col-lg-5">
                    <div class="bottom-footer-center">
                      <ul>
                          <li><a href="#">Terms &amp; Conditions</a></li>
                          <li>|</li>
                          <li><a href="#">Privacy Policy</a></li>
                          <li>|</li>
                          <li><a href="#">Sitemap</a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-lg-2">
                    <div class="bottom-footer-end">
                      <a href="#">Design By: GPB-IT</a>
                    </div>
                  </div>
                  

                      
              <!-- END INNER FOOTER -->
                </div>
                </div>
                
                <!-- END FOOTER SECTION -->
            </div>
        </footer>
        <!--END FOOTER SECTION -->

</div>
<!-- END MAIN WRAPPER -->









    <!-- javascript and jquery -->

    <!-- Swiper JS -->
    <script src="node_modules/swiper/swiper-bundle.min.js"></script>
    
    <!-- bootstrap js -->
    <script src="./assets/js/bootstrap.bundle.min.js"></script>



    <!-- light box -->
    <script src="./assets/lightbox2/dist/js/lightbox-plus-jquery.min.js"></script>
    <script src="./assets/lightbox2/dist/js/lightbox.js"></script>
    
    <!-- jquery -->
    <!-- <script src="./node_modules/jquery/dist/jquery.min.js"></script> -->
    <script src="./assets/js/jquery-main.js"></script>
    <script src="./assets/js/main.js"></script>

 
  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper(".mySwiper", {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script>
</body>
</html>