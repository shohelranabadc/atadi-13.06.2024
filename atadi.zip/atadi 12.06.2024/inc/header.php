<?php include 'vendor/autoload.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <!-- fav icon -->
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/images/favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/images/favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/images/favicon_io/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">

    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Noto+Sans+Bengali:wght@300;400;500;600;800&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    
<!-- font awesome  -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css">

    <!-- bootstrap icons cdn -->
    <link rel="stylesheet" href="node_modules/bootstrap-icons/font/bootstrap-icons.min.css">
    

    <!-- bootstrap  -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <!-- light box 2 -->
    <link rel="stylesheet" href="./assets/lightbox2/dist/css/lightbox.css">


    <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="node_modules/swiper/swiper-bundle.min.css" />

    <!-- css normalize -->
    <link rel="stylesheet" href="./assets/css/reset.css">
    
    <!-- custom css -->
    <link rel="stylesheet" href="./assets/css/custom.css">
    <link rel="stylesheet" href="./assets/css/responsive.css">
    
</head>
<body>

<!-- START MAIN WRAPPER -->
<div id="main-wrapper">
        <!-- START HEADER SECTION -->
        <section id="header" class="header ">
          <div class="container">
            <div class="row school_header_bg">
              <div class="col-md-2 top-logo-container">
                <?php 
                   $schoolMediaCon = new SchoolMediaController();
                   $result = $schoolMediaCon->showData(); 
                ?>
                <div class="logo">
                  <img src="admin/upload/schoolThemeMedia/<?= $result[0]['logo'] ?>" alt="logo" class="img-fluid">
                </div>
              </div>
              <div class="col-md-8">
              <?php 
                   $schoolInfoCon = new SchoolInformationController();
                   $row = $schoolInfoCon->singleRow();
                ?>
              
                <div class="school_name">
                  <h1><?= $row['school_name_bangla']?></h1>
                  <h2>ডাকঘর- <?= $row['school_post_name']?>, উপজেলা- <?= $row['school_police_station']?>, জেলা- <?= $row['school_district_name']?></h2>
                </div>
                <div class="school_identity">
                  <p>এমপিও কোড- <?= $row['school_mpo_code']?></p>
                  <p>ইমেইল- <?= $row['school_email_address']?></p>
                  <p>ইআইআইএন নম্বর- <?= $row['school_eiin_number']?></p>
                </div>
              </div>
              <div class="col-md-2 mujib-logo-container p-0">
                <div class="fifty-years-logo">
                  <img src="admin/upload/schoolThemeMedia/<?= $result[1]['logo'] ?>" alt="mujib_logo" class="img-fluid h-100">
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- END HEADER SECTION -->




        <?php require_once 'nav.php';?>