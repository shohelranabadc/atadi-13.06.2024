<?php require_once __DIR__ . '/admin/Http/Controllers/NoticeController.php'; 

$noticeCon = new NoticeController();

// sent notice file to notice controller
if(isset($_GET['file'])){
  $filename = basename($_GET['file']);
  $downloadNotice = $noticeCon->download($filename);
}


?>


<?php include_once 'inc/header.php'; ?>


        <section class="main_content_section">
            <div class="container px-0">
                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="page_heading text-center">
                            <h1 class="py-3">Notice</h1>
                            <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>

                <div class="row mx-0 my-3">
                    <div class="card border-0">
                      <table class="table table-striped table-hover">
                        <thead class="">
                          <tr>
                            <th>ক্রমিক নং</th>
                            <th>শিরোনাম</th>
                            <th>প্রকাশের তারিখ</th>
                            <th>ডাউনলোড</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                            $noticeCon = new NoticeController();
                            $results = $noticeCon->showData();
                            $count = 0;
                            if ($results) {
                              foreach ($results as $row){ ?>
                          <tr>
                            <td><?= $count++; ?></td>
                            <td> <a target="_blank" href="admin/upload/noticeFile/<?=$row['notice_file']; ?>"><?= $row['notice_title'];?> </a></td>
                            <td><?=$row['created_at']?></td>
                            <td class="d-flex justify-content-center">
                                <!-- Download button -->
                                <a href="?file=<?= urlencode($row['notice_file']); ?>" class="btn btn-sm btn-primary">Download</a>
                            </td>
                          </tr>

                          <?php } 
                      } else {
                        echo "<span class='text-danger'>No Notice Found </span>";
                      } ?>
                            
                        </tbody>
                      </table>
                    </div>
              
              
                  </div>
            </div>
        </section>


        <?php require_once 'inc/footer.php'; ?>