
<?php include 'vendor/autoload.php';?>


<?php include_once 'inc/header.php'; ?>

<!-- START TOP NOTICE SLIDEING -->
<section class="top-notice-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-2 notice-bg-color">
        <div class="notice-title">
          <h5>নোটিশ</h5>
        </div>
      </div>
      <div class="col-lg-10 p-0">
        <div class="notice-scrolling">
          <marquee direction="left" scrollamount="6px" onmouseover="this.stop()" onmouseout="this.start()">
            <?php
            $noticeCon = new NoticeController();
            $results = $noticeCon->showData();

            if ($results) {
              foreach ($results as $row){ ?>

              <a target="_blank" href="admin/upload/noticeFile/<?= $row['notice_file']; ?>">
                <span class="position-relative mx-2 badge text-bg-danger rounded-2">নোটিশ</span>
                <?= $row['notice_title']; ?>
                <i class="fa fa-square" aria-hidden="true"></i>
              </a>

              <?php } 
                      } else {
                        echo "<span class='text-danger'>No Notice Found </span>";
                      } ?>
          </marquee>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- END TOP NOTICE SLIDEING -->

<!-- SLIDING START  -->
<!-- Swiper -->
<section class="home-sliding">
  <div class="container">
    <div class="row">
      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <?php
          $sliderCon = new SliderController();
          $results = $sliderCon->showData();
             
          if ($results) {
              foreach ($results as $row){ ?>

            <div class="swiper-slide"><img src="admin/upload/sliderImage/<?= $row['slider_image_name']; ?>" alt=""></div>

            <?php } 
                      } else {
                        echo "<span class='text-danger'>No Slider Image Found </span>";
                      } ?>

        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
  </div>
</section>
<!-- SLIDING END  -->

<!-- MAIN SECTION START -->
<main>
  <section class="main-section">
    <div class="container p-0">
      <div class="row">

        <!-- LEFT SIDE START --- MAIN SECTION -->
        <div class="col-md-9">
          <!-- school about section -->
          <div class="row p-3">
            <div class="col-md-6">
              <div class="about-school">
                <?php
                $aboutCon = new AboutSchoolController();
                $results = $aboutCon->showData();
             
          if ($results) {
              foreach ($results as $row){ ?>
                  <p class="">
                    <?= $aboutCon->limitWords($row['long_discription'], 102); ?>
                    <a class="read-more-btn" href="about_school"> আরো জানতে <i class="bi bi-arrow-right"></i></a>
                  </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="school-img-section">
                <img src="admin/upload/aboutSchool/<?= $row['image_name'] ?>" alt="" class="">
              </div>
            </div>
          <?php } } else {
                        echo "<span class='text-danger'>No Data Found </span>";
                      } ?>
          </div>

          <!-- principal and head master speech container -->
          <div class="row p-3">
            <div class="col-md-6">
              <div class="profile-container">
                <div class="profile-title custom-bg-color">
                  <p>সভাপতির বার্তা</p>
                </div>
                <?php
                $chairmanMessageCon = new ChairmanMessageController();
                $results = $chairmanMessageCon->showData();
             
          if ($results) {
              foreach ($results as $row){ ?>
                  <div class="profile-image">
                    <img src="admin/upload/chairmanMessagePage/<?= $row['image_name'] ?>" alt="" class="">
                    <p>
                      <?= $chairmanMessageCon->limitWords($row['long_message'], 74); ?>
                      <a class="read-more-btn" href="chairman_speach"> আরো জানতে <i class="bi bi-arrow-right"></i></a>
                    </p>
                  </div>
              </div>
            <?php } } else {
                        echo "<span class='text-danger'>No Data Found </span>";
                      } ?>
            </div>
            <div class="col-md-6">
              <div class="profile-container">
                <div class="profile-title custom-bg-color">
                  <p>প্রধান শিক্ষকের বার্তা</p>
                </div>
                <?php
                $headmasterMessageCon = new HeadmasterMessageController();
                $results = $headmasterMessageCon->showData();
             
          if ($results) {
              foreach ($results as $row){ ?>
                  <div class="profile-image">
                    <img src="admin/upload/headmasterMessagePage/<?= $row['image_name'] ?>" alt="" class="">
                    <p>
                      <?= $headmasterMessageCon->limitWords($row['long_message'], 80); ?>
                      <a class="read-more-btn" href="headmaster_speach">আরো জানতে <i class="bi bi-arrow-right"></i></a>
                    </p>
                  </div>
              </div>
            <?php } } 
                    else {
                        echo "<span class='text-danger'>No Data Found </span>";
                      } ?>
            </div>
          </div>
          <!-- school information start - row 01 -->
          <div class="row p-3">
            <div class="col-md-6">
              <div class="card">
                <div class="card-title">
                  <p>শিক্ষার্থী তথ্য-</p>
                </div>
                <div class="card-body">
                  <div class="card-image"><img src="./assets/images/main_section/card_img/card-one.png" alt=""></div>
                  <div class="card-content">
                    <div class="card-link">
                      <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ক্লাশ ও লিঙ্গভিত্তিক শিক্ষার্থী</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ক্লাশ ও বিভাগ ভিত্তিক শিক্ষার্থী</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>উপবৃত্তিপ্রাপ্ত শিক্ষার্থী</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card">
                <div class="card-title">
                  <p>শিক্ষক/কর্মচাররি তথ্য-</p>
                </div>
                <div class="card-body">
                  <div class="card-image"><img src="./assets/images/main_section/card_img/card-two.png" alt=""></div>
                  <div class="card-content">
                    <div class="card-link">
                      <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>কর্মচারীবৃন্দের তালিকা</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>শিক্ষকবৃন্দের তালিকা</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- row 02 -->
          <div class="row p-2">
            <div class="col-md-6">
              <div class="card">
                <div class="card-title">
                  <p>পাঠদান সংক্রান্ত তথ্য</p>
                </div>
                <div class="card-body">
                  <div class="card-image"><img src="./assets/images/main_section/card_img/card-three.png" alt=""></div>
                  <div class="card-content">
                    <div class="card-link">
                      <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>উপবৃত্তিপ্রাপ্ত শিক্ষার্থী</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ক্লাশ রুটিন</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ছুটির তালিকা</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>মুজিব কর্ণার</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card">
                <div class="card-title">
                  <p>সহপাঠ কার্যক্রম</p>
                </div>
                <div class="card-body">
                  <div class="card-image"><img src="./assets/images/main_section/card_img/card-four.png" alt=""></div>
                  <div class="card-content">
                    <div class="card-link">
                      <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>গার্লস গাইড</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ডিবেটিং ক্লাব</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>বিজ্ঞান ক্লাব</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ষ্টুডেন্ট কাউন্সিল</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>সাহিত্য ও সংস্কৃতি ক্লাব</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- row 03 -->
          <div class="row p-2">
            <div class="col-md-6">
              <div class="card">
                <div class="card-title">
                  <p>ভৌত অবকাঠামো তথ্য</p>
                </div>
                <div class="card-body">
                  <div class="card-image"><img src="./assets/images/main_section/card_img/card-five.png" alt=""></div>
                  <div class="card-content">
                    <div class="card-link">
                      <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ভবন ও কক্ষ তথ্য</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>আইসিটি ও সাইন্স ল্যাব</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>মাল্টিমিডিয়া ক্লাসরুম</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>লাইব্রেরি তথ্য</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card">
                <div class="card-title">
                  <p>ভর্তি তথ্য-</p>
                </div>
                <div class="card-body">
                  <div class="card-image"><img src="./assets/images/main_section/card_img/card-six.png" alt=""></div>
                  <div class="card-content">
                    <div class="card-link">
                      <ul>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>একাদশ শ্রেণি ভর্তি তথ্য</a></li>
                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i>ষষ্ঠ শ্রেণি ভর্তি তথ্য</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- LEFT SIDE END --- MAIN SECTION -->

        <!-- RIGHT SIDE START --- MAIN SECTION -->
        <div class="col-md-3">

          <!-- NOTICE  -->
          <div class="row pt-3">
            <div class="col-md-12">
              <div class="main-section-notice">
                <div class="title">
                  <p>নোটিশ</p>
                </div>
                <div class="content">
                  <ul>
                    <?php
                    $noticeCon = new NoticeController();
                    $results = $noticeCon->showData();
        
                    if ($results) {
                      foreach ($results as $row){ ?>
                      <li>
                        <a target="_blank" href="admin/upload/noticeFile/<?= $row['notice_file']; ?>">
                          <i class="fa fa-check-circle" aria-hidden="true"></i> <?= $row['notice_title']; ?>
                        </a>
                      </li>
                      <?php } 
                      } else {
                        echo "<span class='text-danger'>No Notice Found </span>";
                      } ?>

                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- IMPORTANT LINKS -->
          <div class="row pt-3">
            <div class="col-md-12">
              <div class="main-section-emergency-link">
                <div class="title">
                  <p>গুরুত্বপুর্ণ লিংকসমুহ</p>
                </div>
                <div class="content">
                  <ul>
                    <?php
                     $importantLinkCon = new ImportantLinkController();
                     $results = $importantLinkCon->showData();
         
                     if ($results) {
                       foreach ($results as $row){ ?>
                      <li>
                        <a target="_blank" href="<?= $row['url_link']; ?>">
                          <i class="fa fa-hand-o-right me-2" aria-hidden="true"></i> <?= $row['url_title']; ?></a>
                      </li>
                      <?php } 
                      } else {
                        echo "<span class='text-danger'>No Important Link Found </span>";
                      } ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <!-- CALENDER START -->
          <div class="row pt-3">
            <div class="col-md-12">
              <div class="calendar-container">
                <div class="calendar">
                  <div class="month">
                    <i class="fa fa-chevron-left prev" aria-hidden="true"></i>
                    <div class="date">
                      <h1></h1>
                      <p></p>
                    </div>
                    <i class="fa fa-chevron-right next"></i>
                  </div>
                  <div class="weekdays">
                    <div>Sun</div>
                    <div>Mon</div>
                    <div>Tue</div>
                    <div>Wed</div>
                    <div>Thu</div>
                    <div>Fri</div>
                    <div>Sat</div>
                  </div>
                  <div class="days"></div>
                </div>
              </div>
            </div>

          </div>
          <!-- CALENDER END -->
        </div>
        <!-- RIGHT SIDE END --- MAIN SECTION -->
      </div>
    </div>
  </section>
</main>
<!-- MAIN SECTION END -->

<!-- PHOTO GALARY START -->
<section class="photo-galary">
  <div class="container">
    <div class="phpto-galary-title">
      <h2>ফটো গ্যালারী</h2>
    </div>
    <div class="row">
      <div class="col-md-12 gallery-bg">
        <div class="gallery">
        <?php
          $photoGalleryCon = new PhotoGalleryController();
            $results = $photoGalleryCon->showData();
                 
              if ($results) {
                  foreach ($results as $row){ ?>
                      <img src="admin/upload/schoolPhotoGallery/<?= $row['image_name'] ?>" alt="">
                      <?php } 
                      } else {
                        echo "<span class='text-danger'>No Photo Gallery Found </span>";
                      } ?>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- PHOTO GALARY END -->



<?php require_once 'inc/footer.php'; ?>