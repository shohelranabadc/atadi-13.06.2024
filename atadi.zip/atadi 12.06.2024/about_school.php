<?php include 'vendor/autoload.php';?>

<?php include_once 'inc/header.php'; ?>

<section class="main_content_section">
            <div class="container px-0">
                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="page_heading text-center">
                            <h1 class="py-3">আতাদী উচ্চ বিদ্যালয় সম্পর্কে</h1>
                            <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>

                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="card border-0">
                            <div class="card-body">
                                <p class="about_school_text">
                                <?php
                                   $aboutCon = new AboutSchoolController();
                                    $results = $aboutCon->showData();
         
                                    if ($results) {
                                        foreach ($results as $row){ ?>
                                    
                                    <?= $row['long_discription']; ?>
                                <?php } } ?>

                                </p>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
</section>


<?php require_once 'inc/footer.php'; ?>