<?php include 'vendor/autoload.php';?>

<?php include_once 'inc/header.php'; ?>
<?php
$id = $_GET['id'];
$staff_name = $_GET['staff_name'];
?>

<section class="main_content_section">
    <div class="container px-0">
        <div class="row my-4">
            <div class="col-lg-12">
                <div class="page_heading text-center">
                    <h1 class="py-3">আতাদী উচ্চ বিদ্যালয় সম্পর্কে</h1>
                    <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                </div>
            </div>
        </div>


        <div class="row justify-content-center mb-5">
                <div class="col-6">
                <div class="indivitual-page-heading">
                        <?php
                        if (isset($staff_name)) { ?>
                            <h1 class="text-center text-primary fs-3 text-white">জনাব <?= $staff_name; ?> এর ব্যক্তিগত তথ্য</h1>
                        <?php } ?>
                        

                    </div>
                    <div class="card">
                        <table class="table table-striped table-info table-striped-columns">
                            <tbody>

                            <?php
                                $staffProfileCon = new StaffProfileController();
                                $row = $staffProfileCon->getDataById($id);

                                if ($row) { ?>
                                    <tr>
                                        <td>
                                            <table class="table table-bordered table-primary table-hover table-striped-columns border-primary">
                                                <tr>
                                                    <td colspan="2" class="mx-auto text-center"><img src="./admin/upload/staffProfile/<?php echo $row['image']; ?>" class="img-thumbnail" width="200" min-height="200" alt=""></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">নাম</td>
                                                    <td><?php echo $row['name']; ?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="fw-bolder">পদবী</td>
                                                    <td><?php echo $row['designation']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">ইনডেক্স নম্বর</td>
                                                    <td><?php echo $row['index_number']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">শিক্ষাগত যোগ্যতা</td>
                                                    <td><?php echo $row['qualification']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">বেতন কোড</td>
                                                    <td><?php echo $row['salary_code']; ?></td>
                                                </tr>        
                                                <tr>
                                                    <td class="fw-bolder">অভিজ্ঞতা</td>
                                                    <td><?php echo $row['experience']; ?></td>
                                                </tr>    
                                                <tr>
                                                    <td class="fw-bolder">জন্ম তারিখ</td>
                                                    <td class="fs-6"><?php echo $row['birth_of_date']; ?></td>
                                                </tr>                     
                                                <tr>
                                                    <td class="fw-bolder">যোগদানের তারিখ</td>
                                                    <td class="fs-6"><?php echo $row['date_of_joining']; ?></td>
                                                </tr>
                                                
                                            
                                                <tr>
                                                    <td class="fw-bolder">জাতীয় পরিচয়পত্র নম্বর</td>
                                                    <td><?php echo $row['nid_number']; ?></td>
                                                </tr>
                                                
                                                
                                                <tr>
                                                    <td class="fw-bolder">মোবাইল নম্বর</td>
                                                    <td><?php echo $row['mobile_number']; ?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="fw-bolder">বর্তমান ঠিকানা</td>
                                                    <td><?php echo $row['present_address']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">স্থায়ী ঠিকানা</td>
                                                    <td><?php echo $row['parmanent_address']; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- end col -->
            </div>
       
       
    </div>
</section>


<?php require_once 'inc/footer.php'; ?>