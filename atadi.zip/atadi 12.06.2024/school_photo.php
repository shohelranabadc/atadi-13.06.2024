<?php require_once 'inc/header.php'; ?>


        <section class="main_content_section">
            <div class="container px-0">
                <div class="row my-4">
                    <div class="col-lg-12">
                        <div class="page_heading text-center">
                            <h1 class="py-3">স্কুলের ছবি</h1>
                            <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                        </div>
                    </div>
                </div>

                <div class="row mx-0 my-3">
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_1.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_1.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_2.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_2.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_3.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_3.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_4.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_4.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_5.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_5.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_6.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_6.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_7.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_7.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="./assets/images/photo_gallery/photo_gallery_img_8.jpg"
                            data-lightbox="roadtrip">
                            <img src="./assets/images/photo_gallery/photo_gallery_img_8.jpg"
                                alt="" class="img-fluid img-thumbnail">
                        </a>
                    </div>
                </div>
            </div>
        </section>


        <?php require_once 'inc/footer.php'; ?>