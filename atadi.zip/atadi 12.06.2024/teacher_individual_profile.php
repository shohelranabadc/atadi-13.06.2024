<?php include 'vendor/autoload.php';?>

<?php include_once 'inc/header.php'; ?>

<?php
$id = $_GET['id'];
$teacher_name = $_GET['teacher_name'];


?>

<section class="main_content_section">
    <div class="container px-0">
        <div class="row my-4">
            <div class="col-lg-12">
                <div class="page_heading text-center">
                    <h1 class="py-3">আতাদী উচ্চ বিদ্যালয় সম্পর্কে</h1>
                    <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                </div>
            </div>
        </div>


        <div class="row justify-content-center mb-5">
                <div class="col-6">
                    <div class="indivitual-page-heading">
                        <?php
                        if (isset($teacher_name)) { ?>
                            <h1 class="text-center text-primary fs-3 text-white">জনাব <?= $teacher_name; ?> এর ব্যক্তিগত তথ্য</h1>
                        <?php } ?>
                    </div>
                    <div class="card">
                        <table class="table table-striped table-info table-striped-columns">
                            <tbody>

                            <?php
                                $teacherProfileCon = new TeacherProfileController();
                                $row = $teacherProfileCon->getDataById($id);
                                if ($row) { ?>
                                <tr>

                                    <td>
                                        <table class="table table-bordered table-primary table-hover table-striped-columns border-primary">
                                        <tr>
                                                <td colspan="2" class="mx-auto text-center"><img src="./admin/upload/teachersProfile/<?php echo $row['image']; ?>" class="img-thumbnail" width="200" min-height="200" alt=""></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">নাম</td>
                                                <td><?php echo $row['name']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">ইনডেক্স নম্বর</td>
                                                <td><?php echo $row['index_number']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">পদবী</td>
                                                <td><?php echo $row['designation']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">জন্ম তারিখ</td>
                                                <td class="fs-6"><?php echo $row['birth_of_date']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">১ম যোগদানের তারিখ</td>
                                                <td class="fs-6"><?php echo $row['date_of_first_joining']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">১ম এমপিও চুক্তির তারিখ</td>
                                                <td><?php echo $row['date_of_first_mpo_agreement']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">বর্তমান পদে যোগদানের তারিখ</td>
                                                <td><?php echo $row['date_of_joining_present_post']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">বর্তমান পদে এমপিও চুক্তির তারিখ</td>
                                                <td><?php echo $row['date_of_mpo_contract_in_present_position']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">বেতন কোড</td>
                                                <td><?php echo $row['salary_code']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">নিয়োগের বিষয়</td>
                                                <td><?php echo $row['recruitment_subject']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">মোট অভিজ্ঞতা</td>
                                                <td><?php echo $row['total_experience']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">এএসসি/দাখিল</td>
                                                <td><?php echo $row['ssc_dakhil']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">এইচএসসি/আলিম</td>
                                                <td><?php echo $row['hsc_alim']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">স্নাতক/ফাযিল</td>
                                                <td><?php echo $row['graduate_fazil']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">স্নাতকোত্তর/কামিল</td>
                                                <td><?php echo $row['post_graduate_kamil']; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="fw-bolder">বিএড/এমএড</td>
                                                <td><?php echo $row['bEd_mEd']; ?></td>
                                            </tr>
                                            <?php } ?>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- end col -->
            </div>
       
       
    </div>
</section>


<?php require_once 'inc/footer.php'; ?>