<?php include 'vendor/autoload.php';?>

<?php include_once 'inc/header.php'; ?>

<?php
$id = $_GET['id'];
$director_name = $_GET['director_name'];

?>

<section class="main_content_section">
    <div class="container px-0">
        <div class="row my-4">
            <div class="col-lg-12">
                <div class="page_heading text-center">
                    <h1 class="py-3">আতাদী উচ্চ বিদ্যালয় সম্পর্কে</h1>
                    <i aria-hidden="true" class="fa fa-graduation-cap"></i>
                </div>
            </div>
        </div>


        <div class="row justify-content-center mb-5">
                <div class="col-6">
                    <div class="indivitual-page-heading">
                        <?php
                        if (isset($director_name)) { ?>
                            <h1 class="text-center text-primary fs-3 text-white">জনাব <?= $director_name; ?> এর ব্যক্তিগত তথ্য</h1>
                        <?php } ?>
                    </div>
                    <div class="card">
                        <table class="table table-striped table-info table-striped-columns">
                            <tbody>

                            <?php
                                $directorprofileCon = new DirectorProfileController();
                                $row = $directorprofileCon->getDataById($id);

                                if ($row) { ?>
                                    <tr>
                                        <td>
                                            <table class="table table-bordered table-primary table-hover table-striped-columns border-primary">
                                                <tr>
                                                    <td colspan="2" class="mx-auto text-center"><img src="./admin/upload/directorProfile/<?php echo $row['image']; ?>" class="img-thumbnail" width="200" min-height="200" alt=""></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">নাম</td>
                                                    <td><?php echo $row['name']; ?></td>
                                                </tr>
                                                
                                                <tr>
                                                    <td class="fw-bolder">পদবী</td>
                                                    <td><?php echo $row['designation']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="fw-bolder">যোগাযোগ</td>
                                                    <td><?php echo $row['contact_number']; ?></td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- end col -->
            </div>
       
       
    </div>
</section>


<?php require_once 'inc/footer.php'; ?>